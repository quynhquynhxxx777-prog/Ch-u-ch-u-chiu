# Development

After [forking the repo from GitHub](https://help.github.com/articles/fork-a-repo) and [installing pnpm](https://pnpm.io/installation), run the following:

```shell
git clone https://github.com/(your-name-here)/eslint-plugin-package-json
cd eslint-plugin-package-json
pnpm install
```

> [!TIP]
> This repository includes a list of suggested VS Code extensions.
> We recommend using [VS Code](https://code.visualstudio.com), [Cursor](https://cursor.com), or another VS Code-compatible IDE and accept its prompt to install them.
> If you're not using VS Code, use the equivalent extensions for your editor.

## Building

Run [**tsdown**](https://tsdown.dev) locally to build source files from `src/` into output files in `lib/`:

```shell
pnpm build
```

Add `--watch` to run the builder in watch mode that continuously cleans and recreates `lib/` as you save files:

```shell
pnpm build --watch
```

## Generating Docs

Run [`eslint-doc-generator`](https://github.com/bmish/eslint-doc-generator) to generate new skeleton doc pages for new rules or to update existing doc pages for updated rules:

```shell
pnpm docs:generate
```

## Formatting

[Prettier](https://prettier.io) is used to format code.
It should be applied automatically when you save files in VS Code or make a Git commit.

To manually reformat all files, you can run:

```shell
pnpm format --write
```

## Linting

This package includes a couple forms of linting to enforce consistent code quality and styling.
Each will run at CI time, and can be run manually on the command-line:

- `pnpm lint` ([ESLint](https://eslint.org)): Lints all source files
- `pnpm lint:knip` ([knip](https://github.com/webpro/knip)): Detects unused files, dependencies, and code exports

Read the individual documentation for each tool to understand how it can be configured and used best.

For example, ESLint can be run with `--fix` to auto-fix some lint rule violations:

```shell
pnpm lint --fix
```

## Testing

[Vitest](https://vitest.dev) is used for tests.
You can run it locally on the command-line:

```shell
pnpm test
```

Add the `--coverage` flag to compute test coverage and place reports in the `coverage/` directory:

```shell
pnpm test --coverage
```

Note that [console-fail-test](https://github.com/JoshuaKGoldberg/console-fail-test) is enabled for all test runs.
Calls to `console.log`, `console.warn`, and other console methods will cause a test to fail.

### Debugging Tests

We recommend using the official [Vitest VSCode extension](https://marketplace.visualstudio.com/items?itemName=vitest.explorer) to run and / or debug individual tests (or entire test suites).

## Type Checking

You should be able to see suggestions from [TypeScript](https://typescriptlang.org) in your editor for all open files.

However, it can be useful to run the TypeScript command-line (`tsc`) to type check all files in `src/`:

```shell
pnpm typecheck
```

Add `--watch` to keep the type checker running in a watch mode that updates the display as you save files:

```shell
pnpm typecheck --watch
```

## Working on the Site

If you'd like to work on aspects of the website, these commands might come in helpful.
The site is built using ✨[Starlight](https://starlight.astro.build/) for Astro.

### Run Dev Server

You can spin up a local instance of the server by running `astro dev`.
This will serve the site in "watch" mode, so that updates you make will reflect in the site as you make them.
This will serve the site on `http://localhost:3000/`.

```shell
pnpm site:dev
```

### Build the Site for Production

To create a production build for testing, you can run a combination of the "build" and "preview" commands.
This will create a production build of the site, and serve the statically generated assets locally on the dev server.
This, importantly, is _not_ running in "watch" mode, and won't react to changes to the source files.

```shell
pnpm site:build
pnpm site:preview
```
