# Security Policy

We take all security vulnerabilities seriously.
If you have a vulnerability or other security issues to disclose:

- Thank you very much, please do!
- Please send them to us via [Bluesky](https://bsky.app/profile/michael.faith).

We appreciate your efforts and responsible disclosure and will make every effort to acknowledge your contributions.
