# Changelog

## [1.5.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v1.4.0...v1.5.0) (2026-06-21)


### 🚀 Features

* **require-author:** add fixer to fill in `author` with git data ([#1951](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1951)) ([80f35fc](https://github.com/michaelfaith/eslint-plugin-package-json/commit/80f35fc74c9c882ce23a160737d830ed598ae248))
* **valid-author:** add fixer for replacing empty or invalid `author` ([#1954](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1954)) ([5bf14b9](https://github.com/michaelfaith/eslint-plugin-package-json/commit/5bf14b97a80f57128cfa4bc6dee6f4ed15111aca))

## [1.4.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v1.3.0...v1.4.0) (2026-06-17)


### 🚀 Features

* **sort-collections:** add custom sort order option ([#1936](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1936)) ([fbe0ba4](https://github.com/michaelfaith/eslint-plugin-package-json/commit/fbe0ba41d31a6b8472bd28ac9d032aeddbd2f2dc))


### 🩹 Bug Fixes

* **deps:** update dependency sort-package-json to v4 ([#1912](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1912)) ([ae2a9b0](https://github.com/michaelfaith/eslint-plugin-package-json/commit/ae2a9b071acb965643acd92674adcdc16768cdf0))
* **sort-collections:** improve fixer's indent-matching logic ([#1941](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1941)) ([ffe6c09](https://github.com/michaelfaith/eslint-plugin-package-json/commit/ffe6c09dd6a4e96cafb47c869cd1466a9764712c))

## [1.3.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v1.2.0...v1.3.0) (2026-06-01)


### 🚀 Features

* add `no-local-dependencies` rule ([#1896](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1896)) ([ccb6023](https://github.com/michaelfaith/eslint-plugin-package-json/commit/ccb6023dd571b5226e7c16d070a2a1ab62b6f43d))


### 🏁 Performance Improvements

* **valid-repository-directory:** cache repo root for improved performance in monorepos ([#1907](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1907)) ([88056c3](https://github.com/michaelfaith/eslint-plugin-package-json/commit/88056c3049d263e57f315812aa07bdd8576a2a05))

## [1.2.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v1.1.0...v1.2.0) (2026-05-28)


### 🚀 Features

* **experimental:** add `meta.languages` to all rules ([#1889](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1889)) ([2b8523f](https://github.com/michaelfaith/eslint-plugin-package-json/commit/2b8523f6ca1491db4720e64f02d1056e89369b29))
* **experimental:** add new `/experimental` entry point ([#1874](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1874)) ([48828e6](https://github.com/michaelfaith/eslint-plugin-package-json/commit/48828e61b8b3736becdc0447657bb3ad214b8924))
* **experimental:** export plugin and configs compatible with `@eslint/json` ([#1886](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1886)) ([5a9a1e3](https://github.com/michaelfaith/eslint-plugin-package-json/commit/5a9a1e367a40da39ff25ded9993455d99e5c31e9))

## [1.1.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v1.0.0...v1.1.0) (2026-05-18)


### 🚀 Features

* add `require-peerDependenciesMeta` rule ([#1852](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1852)) ([e66ac55](https://github.com/michaelfaith/eslint-plugin-package-json/commit/e66ac55c64b5be4c829e67884611e335a34db70c))

## [1.0.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.91.2...v1.0.0) (2026-05-17)


### ⚠ BREAKING CHANGES

* add `valid-browser` rule ([#1763](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1763))
* add `valid-bugs` rule ([#1644](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1644))
* add `valid-funding` rule ([#1643](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1643))
* add `valid-gypfile` rule ([#1765](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1765))
* add `valid-libc` rule ([#1764](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1764))
* add `valid-packageManager` rule ([#1640](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1640))
* add `valid-peerDependenciesMeta-relationship` rule ([#1767](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1767))
* add `valid-peerDependenciesMeta` rule ([#1766](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1766))
* drop `legacy-recommended` rc-based config ([#1579](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1579))
* drop support for eslint v8 ([#1589](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1589))
* **order-properties:** remove legacy order option
* remove `valid-package-definition` rule ([#1707](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1707))
* update node engines to `^22.22.2 || >=24.15.0` ([#1824](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1824))
* **valid-name:** refactor to align with other `valid-` rules ([#1821](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1821))

### 🚀 Features

* add `require-browser` rule ([#1835](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1835)) ([56433d0](https://github.com/michaelfaith/eslint-plugin-package-json/commit/56433d0b3ae784a14e700074b678a271804f1e3e))
* add `require-config` rule ([#1834](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1834)) ([24f4eb0](https://github.com/michaelfaith/eslint-plugin-package-json/commit/24f4eb004749ecc953a5ebbc090a256608538f3c))
* add `require-gypfile` rule ([#1836](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1836)) ([d6cc291](https://github.com/michaelfaith/eslint-plugin-package-json/commit/d6cc29190bf3377b6541efa0f6a477012e68b3af))
* add `require-libc` rule ([#1837](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1837)) ([53a208e](https://github.com/michaelfaith/eslint-plugin-package-json/commit/53a208e786fd5ade05a16d00cf90eb5c1121f7d4))
* add `valid-browser` rule ([#1763](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1763)) ([6cb438b](https://github.com/michaelfaith/eslint-plugin-package-json/commit/6cb438bb5c68af1062a5d7a26131795b7aa9a24b))
* add `valid-bugs` rule ([#1644](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1644)) ([f981fa3](https://github.com/michaelfaith/eslint-plugin-package-json/commit/f981fa38ab4f1630c6db0933d859974d0a6ec0b3))
* add `valid-funding` rule ([#1643](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1643)) ([5b3c77d](https://github.com/michaelfaith/eslint-plugin-package-json/commit/5b3c77da9b8edcd659a1fd9b3e51d1e43803aa5e))
* add `valid-gypfile` rule ([#1765](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1765)) ([c14f624](https://github.com/michaelfaith/eslint-plugin-package-json/commit/c14f624137fa11f42f6b5d97357043a94408edd7))
* add `valid-libc` rule ([#1764](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1764)) ([4dd5e9c](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4dd5e9c251e2b4e68571080cfe9fbfeb030b1775))
* add `valid-packageManager` rule ([#1640](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1640)) ([9a65480](https://github.com/michaelfaith/eslint-plugin-package-json/commit/9a65480cb55a4d03043916def549cfd7fc4b604b))
* add `valid-peerDependenciesMeta-relationship` rule ([#1767](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1767)) ([7fc3f0d](https://github.com/michaelfaith/eslint-plugin-package-json/commit/7fc3f0d17ab9be57b3fc118746a38caf9395db18))
* add `valid-peerDependenciesMeta` rule ([#1766](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1766)) ([8731609](https://github.com/michaelfaith/eslint-plugin-package-json/commit/873160958c77caa6b479053a2fad2b41dacc18fe))
* **order-properties:** remove legacy order option ([935f6dc](https://github.com/michaelfaith/eslint-plugin-package-json/commit/935f6dccccdfe7d61deb43e083647a0a1dc8e953))
* remove `valid-package-definition` rule ([#1707](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1707)) ([a4a5b86](https://github.com/michaelfaith/eslint-plugin-package-json/commit/a4a5b86e94b1fd41da8b113f49c96a8149e30fa6))
* update node engines to `^22.22.2 || >=24.15.0` ([#1824](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1824)) ([ce1aa5e](https://github.com/michaelfaith/eslint-plugin-package-json/commit/ce1aa5e222cd17cd25baa9ebf2221642ddc6ed79))
* **valid-name:** refactor to align with other `valid-` rules ([#1821](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1821)) ([2104e75](https://github.com/michaelfaith/eslint-plugin-package-json/commit/2104e75e70eee219d57309e50f1812f8d144a11e))
* **valid-version:** refactor to align with other valid- rules ([#1827](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1827)) ([958c105](https://github.com/michaelfaith/eslint-plugin-package-json/commit/958c10558d4186c9885588c2e7da23e5644d98a6))


### 🩹 Bug Fixes

* improve report range for `require-` rules ([#1840](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1840)) ([1f03c6a](https://github.com/michaelfaith/eslint-plugin-package-json/commit/1f03c6ac732ffae7d29177411a6cbc6798b813da))

## [1.0.0-beta.6](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v1.0.0-beta.5...v1.0.0-beta.6) (2026-05-02)


### ⚠ BREAKING CHANGES

* add `valid-peerDependenciesMeta-relationship` rule ([#1767](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1767))
* add `valid-peerDependenciesMeta` rule ([#1766](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1766))
* add `valid-gypfile` rule ([#1765](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1765))
* add `valid-browser` rule ([#1763](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1763))
* add `valid-libc` rule ([#1764](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1764))

### 🚀 Features

* add `valid-browser` rule ([#1763](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1763)) ([6cb438b](https://github.com/michaelfaith/eslint-plugin-package-json/commit/6cb438bb5c68af1062a5d7a26131795b7aa9a24b))
* add `valid-gypfile` rule ([#1765](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1765)) ([c14f624](https://github.com/michaelfaith/eslint-plugin-package-json/commit/c14f624137fa11f42f6b5d97357043a94408edd7))
* add `valid-libc` rule ([#1764](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1764)) ([4dd5e9c](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4dd5e9c251e2b4e68571080cfe9fbfeb030b1775))
* add `valid-peerDependenciesMeta-relationship` rule ([#1767](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1767)) ([7fc3f0d](https://github.com/michaelfaith/eslint-plugin-package-json/commit/7fc3f0d17ab9be57b3fc118746a38caf9395db18))
* add `valid-peerDependenciesMeta` rule ([#1766](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1766)) ([8731609](https://github.com/michaelfaith/eslint-plugin-package-json/commit/873160958c77caa6b479053a2fad2b41dacc18fe))

## [1.0.0-beta.5](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v1.0.0-beta.4...v1.0.0-beta.5) (2026-04-28)


### 🚀 Features

* add `restrict-top-level-properties` rule ([#1736](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1736)) ([8b29974](https://github.com/michaelfaith/eslint-plugin-package-json/commit/8b29974311212d87c47a0efe4176a9f9506aaf00))


### 🩹 Bug Fixes

* **valid-dependencies:** dependencies should be able to use disttags ([#1749](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1749)) ([316b253](https://github.com/michaelfaith/eslint-plugin-package-json/commit/316b253a978beee05d4055ed73d614546d33f5cd))

## [0.91.2](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.91.1...v0.91.2) (2026-04-28)


### 🚀 Features

* add `restrict-top-level-properties` rule ([#1736](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1736)) ([8b29974](https://github.com/michaelfaith/eslint-plugin-package-json/commit/8b29974311212d87c47a0efe4176a9f9506aaf00))


### 🩹 Bug Fixes

* **valid-dependencies:** dependencies should be able to use disttags ([#1749](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1749)) ([316b253](https://github.com/michaelfaith/eslint-plugin-package-json/commit/316b253a978beee05d4055ed73d614546d33f5cd))

## [1.0.0-beta.4](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v1.0.0-beta.3...v1.0.0-beta.4) (2026-04-06)


### ⚠ BREAKING CHANGES

* **order-properties:** remove legacy order option
* remove `valid-package-definition` rule ([#1707](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1707))

### 🚀 Features

* **order-properties:** remove legacy order option ([935f6dc](https://github.com/michaelfaith/eslint-plugin-package-json/commit/935f6dccccdfe7d61deb43e083647a0a1dc8e953))
* remove `valid-package-definition` rule ([#1707](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1707)) ([a4a5b86](https://github.com/michaelfaith/eslint-plugin-package-json/commit/a4a5b86e94b1fd41da8b113f49c96a8149e30fa6))

## [1.0.0-beta.3](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v1.0.0-beta.2...v1.0.0-beta.3) (2026-04-05)


### 🩹 Bug Fixes

* **no-empty-fields:** Allow `files` to be an empty list ([#1682](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1682)) ([4311f74](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4311f743a79b6fc792822680720106a2a84953d4))

## [0.91.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.91.0...v0.91.1) (2026-03-27)


### 🩹 Bug Fixes

* **no-empty-fields:** Allow `files` to be an empty list ([#1682](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1682)) ([4311f74](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4311f743a79b6fc792822680720106a2a84953d4))

## [1.0.0-beta.2](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v1.0.0-beta.1...v1.0.0-beta.2) (2026-03-13)


### ⚠ BREAKING CHANGES

* add `valid-devEngines` rule ([#1663](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1663))
* add `valid-funding` rule ([#1643](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1643))
* add `valid-bugs` rule ([#1644](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1644))
* add `valid-packageManager` rule ([#1640](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1640))

* merge `main` into `beta` ([4c41fc1](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4c41fc192b4371c1000ad482f5f817cce3599666))


### 🚀 Features

* add `require-bin` rule ([#1652](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1652)) ([434e605](https://github.com/michaelfaith/eslint-plugin-package-json/commit/434e60523a067128e92baa8debf0362ef06c89c6))
* add `require-contributors` rule ([#1648](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1648)) ([4a666ea](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4a666ea9487c4afcc9a0ca0e730d51368266c06a))
* add `require-cpu` rule ([#1659](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1659)) ([40ed2f6](https://github.com/michaelfaith/eslint-plugin-package-json/commit/40ed2f6a97040bcf5d516bcf1ac3e1a3a580c5ee))
* add `require-devEngines` rule ([#1649](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1649)) ([608744c](https://github.com/michaelfaith/eslint-plugin-package-json/commit/608744c3cb29f2dd9808a91cfb99def404a9bdf2))
* add `require-directories` rule ([#1654](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1654)) ([91369d6](https://github.com/michaelfaith/eslint-plugin-package-json/commit/91369d614c72707eeb9f42d73e971645e3ab590f))
* add `require-funding` rule ([#1647](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1647)) ([d2405a1](https://github.com/michaelfaith/eslint-plugin-package-json/commit/d2405a1e6e05ef27bcca850ff5cc034c78c51780))
* add `require-main` rule ([#1631](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1631)) ([f3ea3e6](https://github.com/michaelfaith/eslint-plugin-package-json/commit/f3ea3e6ad7de445449ccfab8fb2472b382b600d5))
* add `require-man` rule ([#1653](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1653)) ([e1cdd8a](https://github.com/michaelfaith/eslint-plugin-package-json/commit/e1cdd8ae35e768772fba92e0188798ac4870099d))
* add `require-os` rule ([#1632](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1632)) ([9b5e25d](https://github.com/michaelfaith/eslint-plugin-package-json/commit/9b5e25dad3d2e5af5882d706d52bce99de0f63b5))
* add `require-private` rule ([#1630](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1630)) ([770cc51](https://github.com/michaelfaith/eslint-plugin-package-json/commit/770cc51bdfe93782ae67ddb3183250c0afe33a3d))
* add `require-publishConfig` rule ([#1629](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1629)) ([ebc187a](https://github.com/michaelfaith/eslint-plugin-package-json/commit/ebc187ae5bde43c7b1f3f27eadfdeea2e67917a9))
* add `valid-bugs` rule ([#1644](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1644)) ([f981fa3](https://github.com/michaelfaith/eslint-plugin-package-json/commit/f981fa38ab4f1630c6db0933d859974d0a6ec0b3))
* add `valid-devEngines` rule ([#1663](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1663)) ([7325be2](https://github.com/michaelfaith/eslint-plugin-package-json/commit/7325be2c6d3bc77467e8da7019ac24861261e27a))
* add `valid-funding` rule ([#1643](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1643)) ([5b3c77d](https://github.com/michaelfaith/eslint-plugin-package-json/commit/5b3c77da9b8edcd659a1fd9b3e51d1e43803aa5e))
* add `valid-packageManager` rule ([#1640](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1640)) ([9a65480](https://github.com/michaelfaith/eslint-plugin-package-json/commit/9a65480cb55a4d03043916def549cfd7fc4b604b))
* add require-module rule ([#1656](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1656)) ([557254c](https://github.com/michaelfaith/eslint-plugin-package-json/commit/557254cac267d1f37fe019662f8293d123aa0e60))


### 🩹 Bug Fixes

* **valid-publishConfig:** rule not reporting violations for deeply nested objects ([#1662](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1662)) ([4c78698](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4c786980b3efc2c25bc9a767a826ec43c3912c2e))

## [0.91.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.90.1...v0.91.0) (2026-03-13)


### ⚠ BREAKING CHANGES

* add `valid-devEngines` rule ([#1663](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1663))

### 🚀 Features

* add `require-cpu` rule ([#1659](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1659)) ([40ed2f6](https://github.com/michaelfaith/eslint-plugin-package-json/commit/40ed2f6a97040bcf5d516bcf1ac3e1a3a580c5ee))
* add `valid-devEngines` rule ([#1663](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1663)) ([7325be2](https://github.com/michaelfaith/eslint-plugin-package-json/commit/7325be2c6d3bc77467e8da7019ac24861261e27a))
* add require-module rule ([#1656](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1656)) ([557254c](https://github.com/michaelfaith/eslint-plugin-package-json/commit/557254cac267d1f37fe019662f8293d123aa0e60))


### 🩹 Bug Fixes

* **valid-publishConfig:** rule not reporting violations for deeply nested objects ([#1662](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1662)) ([4c78698](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4c786980b3efc2c25bc9a767a826ec43c3912c2e))

## [0.90.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.90.0...v0.90.1) (2026-03-10)


### 🚀 Features

* add `require-bin` rule ([#1652](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1652)) ([434e605](https://github.com/michaelfaith/eslint-plugin-package-json/commit/434e60523a067128e92baa8debf0362ef06c89c6))
* add `require-contributors` rule ([#1648](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1648)) ([4a666ea](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4a666ea9487c4afcc9a0ca0e730d51368266c06a))
* add `require-devEngines` rule ([#1649](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1649)) ([608744c](https://github.com/michaelfaith/eslint-plugin-package-json/commit/608744c3cb29f2dd9808a91cfb99def404a9bdf2))
* add `require-directories` rule ([#1654](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1654)) ([91369d6](https://github.com/michaelfaith/eslint-plugin-package-json/commit/91369d614c72707eeb9f42d73e971645e3ab590f))
* add `require-funding` rule ([#1647](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1647)) ([d2405a1](https://github.com/michaelfaith/eslint-plugin-package-json/commit/d2405a1e6e05ef27bcca850ff5cc034c78c51780))
* add `require-man` rule ([#1653](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1653)) ([e1cdd8a](https://github.com/michaelfaith/eslint-plugin-package-json/commit/e1cdd8ae35e768772fba92e0188798ac4870099d))

## [0.90.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.89.4...v0.90.0) (2026-03-10)


### ⚠ BREAKING CHANGES

* add `valid-funding` rule ([#1643](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1643))
* add `valid-bugs` rule ([#1644](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1644))
* add `valid-packageManager` rule ([#1640](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1640))

### 🚀 Features

* add `valid-bugs` rule ([#1644](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1644)) ([f981fa3](https://github.com/michaelfaith/eslint-plugin-package-json/commit/f981fa38ab4f1630c6db0933d859974d0a6ec0b3))
* add `valid-funding` rule ([#1643](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1643)) ([5b3c77d](https://github.com/michaelfaith/eslint-plugin-package-json/commit/5b3c77da9b8edcd659a1fd9b3e51d1e43803aa5e))
* add `valid-packageManager` rule ([#1640](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1640)) ([9a65480](https://github.com/michaelfaith/eslint-plugin-package-json/commit/9a65480cb55a4d03043916def549cfd7fc4b604b))

## [0.89.4](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.89.3...v0.89.4) (2026-03-07)


### 🚀 Features

* add `require-main` rule ([#1631](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1631)) ([f3ea3e6](https://github.com/michaelfaith/eslint-plugin-package-json/commit/f3ea3e6ad7de445449ccfab8fb2472b382b600d5))
* add `require-os` rule ([#1632](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1632)) ([9b5e25d](https://github.com/michaelfaith/eslint-plugin-package-json/commit/9b5e25dad3d2e5af5882d706d52bce99de0f63b5))
* add `require-private` rule ([#1630](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1630)) ([770cc51](https://github.com/michaelfaith/eslint-plugin-package-json/commit/770cc51bdfe93782ae67ddb3183250c0afe33a3d))
* add `require-publishConfig` rule ([#1629](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1629)) ([ebc187a](https://github.com/michaelfaith/eslint-plugin-package-json/commit/ebc187ae5bde43c7b1f3f27eadfdeea2e67917a9))

## [1.0.0-beta.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v1.0.0-beta.0...v1.0.0-beta.1) (2026-03-04)


### 🚀 Features

* enable `ignorePrivate` on more `require-` rules ([#1607](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1607)) ([a187fa8](https://github.com/michaelfaith/eslint-plugin-package-json/commit/a187fa893154c89c3b9dde28d9d0fd6dc1d1173b))


### 🩹 Bug Fixes

* update repo references ([#1613](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1613)) ([079d3af](https://github.com/michaelfaith/eslint-plugin-package-json/commit/079d3af2c67a38ef476121158047e42d9c7ae4c7))

## [0.89.3](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.89.2...v0.89.3) (2026-03-04)


### 🚀 Features

* add `require-packageManager` rule ([#1620](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1620)) ([7626cd9](https://github.com/michaelfaith/eslint-plugin-package-json/commit/7626cd9814cad3bcb1285e37e83af05fb0c067e5))


### 🩹 Bug Fixes

* update repo references ([#1613](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1613)) ([b382fc1](https://github.com/michaelfaith/eslint-plugin-package-json/commit/b382fc11eef19cddc4e1f46861752cc831cd29b8))

## [0.89.2](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.89.1...v0.89.2) (2026-02-27)


### 🚀 Features

* enable `ignorePrivate` on more `require-` rules ([#1607](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1607)) ([4004220](https://github.com/michaelfaith/eslint-plugin-package-json/commit/40042206b40315bdc5b893755d28834a3247db16))


### 🩹 Bug Fixes

* **deps:** update `package-json-validator` to 1.0.1 ([#1599](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1599)) ([8550731](https://github.com/michaelfaith/eslint-plugin-package-json/commit/85507312bd6fe0d8a62f1e978bb27cac9abf8489))

## [1.0.0-beta.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.89.1...v1.0.0-beta.0) (2026-02-24)


### ⚠ BREAKING CHANGES

* drop support for eslint v8 ([#1589](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1589))
* drop `legacy-recommended` rc-based config ([#1579](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1579))
* drop support for end-of-life Node versions ([#1580](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1580))

### 🚀 Features

* drop `legacy-recommended` rc-based config ([#1579](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1579)) ([39a8058](https://github.com/michaelfaith/eslint-plugin-package-json/commit/39a80580c4c499450e6c9ddfe41913aa317848b3))
* drop support for end-of-life Node versions ([#1580](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1580)) ([54f4308](https://github.com/michaelfaith/eslint-plugin-package-json/commit/54f430868b00a287a5b66fba8ff6fbf6c9b64727))
* drop support for eslint v8 ([#1589](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1589)) ([3974c8f](https://github.com/michaelfaith/eslint-plugin-package-json/commit/3974c8f88d091f8e2b90d96cf97f44cac0cf812d))
* move `jsconc-eslint-parser` to be a regular dependency ([#1595](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1595)) ([2e24db6](https://github.com/michaelfaith/eslint-plugin-package-json/commit/2e24db68dfd10ec148569bb8d346112de6a51f19))


### 🩹 Bug Fixes

* **deps:** update `package-json-validator` to 1.0.1 ([#1599](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1599)) ([8550731](https://github.com/michaelfaith/eslint-plugin-package-json/commit/85507312bd6fe0d8a62f1e978bb27cac9abf8489))

## [0.89.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.89.0...v0.89.1) (2026-02-22)


### 🚀 Features

* add support for jsonc-eslint-parser v3 ([#1590](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1590)) ([dd1b959](https://github.com/michaelfaith/eslint-plugin-package-json/commit/dd1b9598d2c94f79a8d5404afda6e565869fe8f0))

## [0.89.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.88.3...v0.89.0) (2026-02-20)


### ⚠ BREAKING CHANGES

* move the `publishable` require rules to `recommended` ([#1565](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1565))

### 🚀 Features

* add support for eslint v10  ([#1554](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1554)) ([27ca725](https://github.com/michaelfaith/eslint-plugin-package-json/commit/27ca725ac5418f5b4076a5890876bd51e3e90d34))
* move the `publishable` require rules to `recommended` ([#1565](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1565)) ([37231d3](https://github.com/michaelfaith/eslint-plugin-package-json/commit/37231d321aff449912b6013b8d6ead78caff3695))

## [0.88.3](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.88.2...v0.88.3) (2026-02-16)


### 🚀 Features

* **require-attribution:** add `ignorePrivate` option ([#1566](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1566)) ([629a8ab](https://github.com/michaelfaith/eslint-plugin-package-json/commit/629a8abf2a51eb9d2dc4e6204c9159a8c8c23675))

## [0.88.2](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.88.1...v0.88.2) (2026-01-23)
## [0.88.2](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.88.1...v0.88.2) (2026-01-23)


### Features

* **require-type:** add auto-fix ([#1534](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1534)) ([c8e44e4](https://github.com/michaelfaith/eslint-plugin-package-json/commit/c8e44e472ac94fc61e0f79e00e4ac2f371718d38))
* **require-type:** add auto-fix ([#1534](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1534)) ([c8e44e4](https://github.com/michaelfaith/eslint-plugin-package-json/commit/c8e44e472ac94fc61e0f79e00e4ac2f371718d38))


### Bug Fixes

* **deps:** update dependency package-json-validator to ~0.60.0 ([#1513](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1513)) ([5b300b6](https://github.com/michaelfaith/eslint-plugin-package-json/commit/5b300b64c52c233b5835b1fda1815551ac0f77b6))
* **deps:** update dependency package-json-validator to ~0.60.0 ([#1513](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1513)) ([5b300b6](https://github.com/michaelfaith/eslint-plugin-package-json/commit/5b300b64c52c233b5835b1fda1815551ac0f77b6))

## [0.88.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.88.0...v0.88.1) (2026-01-07)
## [0.88.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.88.0...v0.88.1) (2026-01-07)


### Features

* add require-scripts rule ([#1505](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1505)) ([f326161](https://github.com/michaelfaith/eslint-plugin-package-json/commit/f326161f63a812c5a3c92a914d17d9ef6fc5dbd2))
* add require-scripts rule ([#1505](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1505)) ([f326161](https://github.com/michaelfaith/eslint-plugin-package-json/commit/f326161f63a812c5a3c92a914d17d9ef6fc5dbd2))

## [0.88.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.87.1...v0.88.0) (2026-01-04)
## [0.88.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.87.1...v0.88.0) (2026-01-04)


### ⚠ BREAKING CHANGES

* add require-repository rule ([#1491](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1491))
* add require-repository rule ([#1491](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1491))

### Features

* add require-repository rule ([#1491](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1491)) ([4d802c5](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4d802c577713a8056c02543faa902b49b3a4950a))
* add require-repository rule ([#1491](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1491)) ([4d802c5](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4d802c577713a8056c02543faa902b49b3a4950a))


### Bug Fixes

* **repository-shorthand:** support repo provider prefix ([#1472](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1472)) ([fb5f10a](https://github.com/michaelfaith/eslint-plugin-package-json/commit/fb5f10a55078eb9aaeefca690275f67ab136592e))
* **valid-repository:** support dashes and dots in repo shorthand ([#1468](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1468)) ([8b83678](https://github.com/michaelfaith/eslint-plugin-package-json/commit/8b83678666f3a0303ac40fadd916faf1ba94020b))
* **repository-shorthand:** support repo provider prefix ([#1472](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1472)) ([fb5f10a](https://github.com/michaelfaith/eslint-plugin-package-json/commit/fb5f10a55078eb9aaeefca690275f67ab136592e))
* **valid-repository:** support dashes and dots in repo shorthand ([#1468](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1468)) ([8b83678](https://github.com/michaelfaith/eslint-plugin-package-json/commit/8b83678666f3a0303ac40fadd916faf1ba94020b))

## [0.87.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.87.0...v0.87.1) (2025-12-31)
## [0.87.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.87.0...v0.87.1) (2025-12-31)


### Features

* add require-homepage rule ([#1480](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1480)) ([0d895ff](https://github.com/michaelfaith/eslint-plugin-package-json/commit/0d895ff8b5c800df07bdf2ed2bc99e1ad16649ad))
* add require-homepage rule ([#1480](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1480)) ([0d895ff](https://github.com/michaelfaith/eslint-plugin-package-json/commit/0d895ff8b5c800df07bdf2ed2bc99e1ad16649ad))

## [0.87.0](///compare/v0.86.0...v0.87.0) (2025-12-30)

### Features

- move `order-properties` from `recommended` to `stylistic` config ([#1475](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1475)) ([b9a9978](https://github.com/michaelfaith/eslint-plugin-package-json/commit/b9a9978ed22b2c8184d10dc63da4435fb0864f29)), closes [#1471](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1471)
- move `order-properties` from `recommended` to `stylistic` config ([#1475](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1475)) ([b9a9978](https://github.com/michaelfaith/eslint-plugin-package-json/commit/b9a9978ed22b2c8184d10dc63da4435fb0864f29)), closes [#1471](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1471)

## [0.86.0](///compare/v0.85.0...v0.86.0) (2025-12-30)

### Features

- remove deprecated valid-local-dependency rule ([#1450](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1450)) ([3e36e30](https://github.com/michaelfaith/eslint-plugin-package-json/commit/3e36e30efef51ed010480e43373e9ac20c9b2014)), closes [#1168](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1168)
- **valid-module:** add rule to validate `module` ([#1462](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1462)) ([ee376e0](https://github.com/michaelfaith/eslint-plugin-package-json/commit/ee376e05fad0ba3f137047124a1975893ecc4ca6)), closes [#1034](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1034)
- remove deprecated valid-local-dependency rule ([#1450](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1450)) ([3e36e30](https://github.com/michaelfaith/eslint-plugin-package-json/commit/3e36e30efef51ed010480e43373e9ac20c9b2014)), closes [#1168](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1168)
- **valid-module:** add rule to validate `module` ([#1462](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1462)) ([ee376e0](https://github.com/michaelfaith/eslint-plugin-package-json/commit/ee376e05fad0ba3f137047124a1975893ecc4ca6)), closes [#1034](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1034)

## [0.85.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.84.0...v0.85.0) (2025-11-18)
## [0.85.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.84.0...v0.85.0) (2025-11-18)

### Features

- **valid-sideEffects:** add new rule for validating `sideEffects` ([#1414](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1414)) ([04b86b1](https://github.com/michaelfaith/eslint-plugin-package-json/commit/04b86b1a5e86cae4187ca1629ba916066d49b086))
- **valid-sideEffects:** add new rule for validating `sideEffects` ([#1414](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1414)) ([04b86b1](https://github.com/michaelfaith/eslint-plugin-package-json/commit/04b86b1a5e86cae4187ca1629ba916066d49b086))

## [0.84.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.83.0...v0.84.0) (2025-11-18)
## [0.84.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.83.0...v0.84.0) (2025-11-18)

### Features

- add new `recommended-publishable` config ([#1413](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1413)) ([ba313a6](https://github.com/michaelfaith/eslint-plugin-package-json/commit/ba313a6ca0b701c152986a83a377b9541c2b20c8)), closes [#1403](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1403)
- add new `recommended-publishable` config ([#1413](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1413)) ([ba313a6](https://github.com/michaelfaith/eslint-plugin-package-json/commit/ba313a6ca0b701c152986a83a377b9541c2b20c8)), closes [#1403](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1403)

## [0.83.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.82.0...v0.83.0) (2025-11-17)
## [0.83.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.82.0...v0.83.0) (2025-11-17)

### Features

- **specify-peers-locally:** add rule to require all peers are declared as dev dependencies ([#1407](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1407)) ([5a102ec](https://github.com/michaelfaith/eslint-plugin-package-json/commit/5a102ecd0f6fb025f42e838492844e2fa32ba786)), closes [#1053](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1053)
- **specify-peers-locally:** add rule to require all peers are declared as dev dependencies ([#1407](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1407)) ([5a102ec](https://github.com/michaelfaith/eslint-plugin-package-json/commit/5a102ecd0f6fb025f42e838492844e2fa32ba786)), closes [#1053](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1053)

## [0.82.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.81.0...v0.82.0) (2025-11-17)
## [0.82.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.81.0...v0.82.0) (2025-11-17)

### Features

- **require-sideEffects:** add new rule for requiring `sideEffects` ([#1406](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1406)) ([0a8388d](https://github.com/michaelfaith/eslint-plugin-package-json/commit/0a8388d6be21e6d4d7c0203fd65be96751ca5f29)), closes [#1405](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1405)
- **require-sideEffects:** add new rule for requiring `sideEffects` ([#1406](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1406)) ([0a8388d](https://github.com/michaelfaith/eslint-plugin-package-json/commit/0a8388d6be21e6d4d7c0203fd65be96751ca5f29)), closes [#1405](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1405)

## [0.81.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.80.0...v0.81.0) (2025-11-17)
## [0.81.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.80.0...v0.81.0) (2025-11-17)

### Features

- **require-attribution:** add new rule to require proper attribution ([#1408](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1408)) ([e646f94](https://github.com/michaelfaith/eslint-plugin-package-json/commit/e646f941bfc8ac2e4cb7c28509a8bd800b912442)), closes [#1404](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1404)
- **require-attribution:** add new rule to require proper attribution ([#1408](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1408)) ([e646f94](https://github.com/michaelfaith/eslint-plugin-package-json/commit/e646f941bfc8ac2e4cb7c28509a8bd800b912442)), closes [#1404](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1404)

## [0.80.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.79.0...v0.80.0) (2025-11-17)
## [0.80.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.79.0...v0.80.0) (2025-11-17)

### Features

- **require-exports:** add new rule to require `exports` ([#1410](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1410)) ([c8fd152](https://github.com/michaelfaith/eslint-plugin-package-json/commit/c8fd1525b4d25c4d1fbdb488a7a604037e352361)), closes [#1409](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1409)
- **require-exports:** add new rule to require `exports` ([#1410](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1410)) ([c8fd152](https://github.com/michaelfaith/eslint-plugin-package-json/commit/c8fd1525b4d25c4d1fbdb488a7a604037e352361)), closes [#1409](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1409)

## [0.79.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.78.0...v0.79.0) (2025-11-15)
## [0.79.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.78.0...v0.79.0) (2025-11-15)

### Features

- deprecate `valid-package-definition` ([#1400](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1400)) ([dca815a](https://github.com/michaelfaith/eslint-plugin-package-json/commit/dca815ae441d7d0667fcd54933eee868197b31d7)), closes [#1399](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1399)
- deprecate `valid-package-definition` ([#1400](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1400)) ([dca815a](https://github.com/michaelfaith/eslint-plugin-package-json/commit/dca815ae441d7d0667fcd54933eee868197b31d7)), closes [#1399](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1399)

## [0.78.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.77.0...v0.78.0) (2025-11-15)
## [0.78.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.77.0...v0.78.0) (2025-11-15)

### Features

- **valid-repository:** add new rule for validating `repository` ([#1393](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1393)) ([2b38e88](https://github.com/michaelfaith/eslint-plugin-package-json/commit/2b38e881f60d357f9f73ad7a1aff159682542c42)), closes [#838](https://github.com/michaelfaith/eslint-plugin-package-json/issues/838)
- **valid-repository:** add new rule for validating `repository` ([#1393](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1393)) ([2b38e88](https://github.com/michaelfaith/eslint-plugin-package-json/commit/2b38e881f60d357f9f73ad7a1aff159682542c42)), closes [#838](https://github.com/michaelfaith/eslint-plugin-package-json/issues/838)

## [0.77.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.76.0...v0.77.0) (2025-11-15)
## [0.77.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.76.0...v0.77.0) (2025-11-15)

### Features

- **unique-dependencies:** report cross-group duplicates ([#1398](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1398)) ([94b690e](https://github.com/michaelfaith/eslint-plugin-package-json/commit/94b690e1996ec271ba743225ccecf66691f97e01)), closes [#1007](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1007)
- **unique-dependencies:** report cross-group duplicates ([#1398](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1398)) ([94b690e](https://github.com/michaelfaith/eslint-plugin-package-json/commit/94b690e1996ec271ba743225ccecf66691f97e01)), closes [#1007](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1007)

## [0.76.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.75.0...v0.76.0) (2025-11-15)
## [0.76.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.75.0...v0.76.0) (2025-11-15)

### Features

- **valid-engines:** add new rule for validating `engines` ([#1397](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1397)) ([ba834f0](https://github.com/michaelfaith/eslint-plugin-package-json/commit/ba834f00651b64f2bc0cf58cf41d768bd6cee5eb)), closes [#826](https://github.com/michaelfaith/eslint-plugin-package-json/issues/826)
- **valid-engines:** add new rule for validating `engines` ([#1397](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1397)) ([ba834f0](https://github.com/michaelfaith/eslint-plugin-package-json/commit/ba834f00651b64f2bc0cf58cf41d768bd6cee5eb)), closes [#826](https://github.com/michaelfaith/eslint-plugin-package-json/issues/826)

## [0.75.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.73.0...v0.75.0) (2025-11-15)
## [0.75.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.73.0...v0.75.0) (2025-11-15)

### Features

- **valid-man:** add new rule for validating `man` ([#1392](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1392)) ([3f1ffc5](https://github.com/michaelfaith/eslint-plugin-package-json/commit/3f1ffc57a924c080892dd66bc5ce7a011ca70451)), closes [#832](https://github.com/michaelfaith/eslint-plugin-package-json/issues/832)
- **valid-publishConfig:** add new rule for validating `publishConfig` ([#1388](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1388)) ([6d1fab4](https://github.com/michaelfaith/eslint-plugin-package-json/commit/6d1fab4e4b6c59e7bcfc582ef75a0e07a5c8ea08)), closes [#841](https://github.com/michaelfaith/eslint-plugin-package-json/issues/841)
- **valid-workspaces:** add new rule for validating `workspaces` ([#1396](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1396)) ([2eeca42](https://github.com/michaelfaith/eslint-plugin-package-json/commit/2eeca42701a8636704e3d6b896cf3eec21531779)), closes [#843](https://github.com/michaelfaith/eslint-plugin-package-json/issues/843)
- **valid-man:** add new rule for validating `man` ([#1392](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1392)) ([3f1ffc5](https://github.com/michaelfaith/eslint-plugin-package-json/commit/3f1ffc57a924c080892dd66bc5ce7a011ca70451)), closes [#832](https://github.com/michaelfaith/eslint-plugin-package-json/issues/832)
- **valid-publishConfig:** add new rule for validating `publishConfig` ([#1388](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1388)) ([6d1fab4](https://github.com/michaelfaith/eslint-plugin-package-json/commit/6d1fab4e4b6c59e7bcfc582ef75a0e07a5c8ea08)), closes [#841](https://github.com/michaelfaith/eslint-plugin-package-json/issues/841)
- **valid-workspaces:** add new rule for validating `workspaces` ([#1396](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1396)) ([2eeca42](https://github.com/michaelfaith/eslint-plugin-package-json/commit/2eeca42701a8636704e3d6b896cf3eec21531779)), closes [#843](https://github.com/michaelfaith/eslint-plugin-package-json/issues/843)

## [0.74.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.73.0...v0.74.0) (2025-11-14)
## [0.74.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.73.0...v0.74.0) (2025-11-14)

### Features

- **valid-publishConfig:** add new rule for validating `publishConfig` ([#1388](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1388)) ([6d1fab4](https://github.com/michaelfaith/eslint-plugin-package-json/commit/6d1fab4e4b6c59e7bcfc582ef75a0e07a5c8ea08)), closes [#841](https://github.com/michaelfaith/eslint-plugin-package-json/issues/841)
- **valid-publishConfig:** add new rule for validating `publishConfig` ([#1388](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1388)) ([6d1fab4](https://github.com/michaelfaith/eslint-plugin-package-json/commit/6d1fab4e4b6c59e7bcfc582ef75a0e07a5c8ea08)), closes [#841](https://github.com/michaelfaith/eslint-plugin-package-json/issues/841)

## [0.73.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.72.0...v0.73.0) (2025-11-13)
## [0.73.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.72.0...v0.73.0) (2025-11-13)

### Features

- **order-properties:** lexicographically sort non-standard properties ([#1375](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1375)) ([f7c0d01](https://github.com/michaelfaith/eslint-plugin-package-json/commit/f7c0d019b91aab831f7506e213cc1176bd5dac75)), closes [#1374](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1374)
- **order-properties:** lexicographically sort non-standard properties ([#1375](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1375)) ([f7c0d01](https://github.com/michaelfaith/eslint-plugin-package-json/commit/f7c0d019b91aab831f7506e213cc1176bd5dac75)), closes [#1374](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1374)

## [0.72.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.71.0...v0.72.0) (2025-11-13)
## [0.72.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.71.0...v0.72.0) (2025-11-13)

### Features

- **valid-contributors:** add new rule for validating `contributors` ([#1387](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1387)) ([82a844c](https://github.com/michaelfaith/eslint-plugin-package-json/commit/82a844cf472a06f2da036a39137f79f3ca1e6c5d)), closes [#1372](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1372)
- **valid-contributors:** add new rule for validating `contributors` ([#1387](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1387)) ([82a844c](https://github.com/michaelfaith/eslint-plugin-package-json/commit/82a844cf472a06f2da036a39137f79f3ca1e6c5d)), closes [#1372](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1372)

## [0.71.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.70.0...v0.71.0) (2025-11-13)
## [0.71.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.70.0...v0.71.0) (2025-11-13)

### Features

- **valid-os:** add new rule for validating `os` ([#1383](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1383)) ([896cd53](https://github.com/michaelfaith/eslint-plugin-package-json/commit/896cd53fee7b1c881102de62f9f7e032a3673ea8)), closes [#834](https://github.com/michaelfaith/eslint-plugin-package-json/issues/834)
- **valid-os:** add new rule for validating `os` ([#1383](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1383)) ([896cd53](https://github.com/michaelfaith/eslint-plugin-package-json/commit/896cd53fee7b1c881102de62f9f7e032a3673ea8)), closes [#834](https://github.com/michaelfaith/eslint-plugin-package-json/issues/834)

## [0.70.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.69.0...v0.70.0) (2025-11-13)
## [0.70.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.69.0...v0.70.0) (2025-11-13)

### Features

- **valid-private:** add new rule for validating `private` ([#1384](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1384)) ([9a9b3d2](https://github.com/michaelfaith/eslint-plugin-package-json/commit/9a9b3d27c5553088cdb224861f122a341acd01bf)), closes [#837](https://github.com/michaelfaith/eslint-plugin-package-json/issues/837)
- **valid-private:** add new rule for validating `private` ([#1384](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1384)) ([9a9b3d2](https://github.com/michaelfaith/eslint-plugin-package-json/commit/9a9b3d27c5553088cdb224861f122a341acd01bf)), closes [#837](https://github.com/michaelfaith/eslint-plugin-package-json/issues/837)

## [0.69.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.68.0...v0.69.0) (2025-11-12)
## [0.69.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.68.0...v0.69.0) (2025-11-12)

### Features

- **valid-main:** add new rule for validating `main` ([#1382](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1382)) ([bc54025](https://github.com/michaelfaith/eslint-plugin-package-json/commit/bc54025bda030013b9129dfb31332327369ad6e7)), closes [#831](https://github.com/michaelfaith/eslint-plugin-package-json/issues/831)
- **valid-main:** add new rule for validating `main` ([#1382](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1382)) ([bc54025](https://github.com/michaelfaith/eslint-plugin-package-json/commit/bc54025bda030013b9129dfb31332327369ad6e7)), closes [#831](https://github.com/michaelfaith/eslint-plugin-package-json/issues/831)

## [0.68.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.67.0...v0.68.0) (2025-11-12)
## [0.68.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.67.0...v0.68.0) (2025-11-12)

### Features

- **valid-keywords:** add new rule for validating `keywords` ([#1381](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1381)) ([a227184](https://github.com/michaelfaith/eslint-plugin-package-json/commit/a2271843a104288376da9b1fbc89e1de33444a38)), closes [#829](https://github.com/michaelfaith/eslint-plugin-package-json/issues/829)
- **valid-keywords:** add new rule for validating `keywords` ([#1381](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1381)) ([a227184](https://github.com/michaelfaith/eslint-plugin-package-json/commit/a2271843a104288376da9b1fbc89e1de33444a38)), closes [#829](https://github.com/michaelfaith/eslint-plugin-package-json/issues/829)

## [0.67.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.66.0...v0.67.0) (2025-11-12)
## [0.67.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.66.0...v0.67.0) (2025-11-12)

### Features

- **valid-files:** add new rule for validating `files` ([#1380](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1380)) ([d2a81d3](https://github.com/michaelfaith/eslint-plugin-package-json/commit/d2a81d3c1c86a24c675fb2ff8483a7e01400b294)), closes [#827](https://github.com/michaelfaith/eslint-plugin-package-json/issues/827)
- **valid-files:** add new rule for validating `files` ([#1380](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1380)) ([d2a81d3](https://github.com/michaelfaith/eslint-plugin-package-json/commit/d2a81d3c1c86a24c675fb2ff8483a7e01400b294)), closes [#827](https://github.com/michaelfaith/eslint-plugin-package-json/issues/827)

## [0.66.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.65.3...v0.66.0) (2025-11-11)
## [0.66.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.65.3...v0.66.0) (2025-11-11)

### Features

- **valid-homepage:** add new rule for validating `homepage` ([#1376](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1376)) ([34ad9b8](https://github.com/michaelfaith/eslint-plugin-package-json/commit/34ad9b8dda81601e9f710dc66c61a02fe7ecfa0e)), closes [#828](https://github.com/michaelfaith/eslint-plugin-package-json/issues/828)
- **valid-homepage:** add new rule for validating `homepage` ([#1376](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1376)) ([34ad9b8](https://github.com/michaelfaith/eslint-plugin-package-json/commit/34ad9b8dda81601e9f710dc66c61a02fe7ecfa0e)), closes [#828](https://github.com/michaelfaith/eslint-plugin-package-json/issues/828)

## [0.65.3](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.65.2...v0.65.3) (2025-11-10)
## [0.65.3](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.65.2...v0.65.3) (2025-11-10)

### Bug Fixes

- **valid-dependencies:** improve report precision ([#1363](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1363)) ([336677a](https://github.com/michaelfaith/eslint-plugin-package-json/commit/336677af4b94834e729b21a450992ca998d42099)), closes [#1213](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1213)
- **valid-dependencies:** improve report precision ([#1363](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1363)) ([336677a](https://github.com/michaelfaith/eslint-plugin-package-json/commit/336677af4b94834e729b21a450992ca998d42099)), closes [#1213](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1213)

## [0.65.2](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.65.1...v0.65.2) (2025-11-10)
## [0.65.2](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.65.1...v0.65.2) (2025-11-10)

### Bug Fixes

- **valid-exports:** improve report precision ([#1361](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1361)) ([5d7bd4a](https://github.com/michaelfaith/eslint-plugin-package-json/commit/5d7bd4affb93c3eb22576062c963599b6e56bdd1)), closes [#000](https://github.com/michaelfaith/eslint-plugin-package-json/issues/000)
- **valid-exports:** improve report precision ([#1361](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1361)) ([5d7bd4a](https://github.com/michaelfaith/eslint-plugin-package-json/commit/5d7bd4affb93c3eb22576062c963599b6e56bdd1)), closes [#000](https://github.com/michaelfaith/eslint-plugin-package-json/issues/000)

## [0.65.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.65.0...v0.65.1) (2025-11-09)
## [0.65.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.65.0...v0.65.1) (2025-11-09)

### Bug Fixes

- **scripts-name-casing:** ignore `prepublishOnly` built-in script ([#1369](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1369)) ([b672551](https://github.com/michaelfaith/eslint-plugin-package-json/commit/b67255122ac753d1c3f9d7ef310a72dca029f2a3)), closes [#1368](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1368)
- **scripts-name-casing:** ignore `prepublishOnly` built-in script ([#1369](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1369)) ([b672551](https://github.com/michaelfaith/eslint-plugin-package-json/commit/b67255122ac753d1c3f9d7ef310a72dca029f2a3)), closes [#1368](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1368)

## [0.65.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.64.0...v0.65.0) (2025-11-08)
## [0.65.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.64.0...v0.65.0) (2025-11-08)

### Bug Fixes

- **valid-bin, valid-bundleDependencies:** improve report precision ([#1360](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1360)) ([3d0bd1e](https://github.com/michaelfaith/eslint-plugin-package-json/commit/3d0bd1e04b935d30e85823dcf8c8d682ea4ab8d2)), closes [#000](https://github.com/michaelfaith/eslint-plugin-package-json/issues/000)
- **valid-bin, valid-bundleDependencies:** improve report precision ([#1360](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1360)) ([3d0bd1e](https://github.com/michaelfaith/eslint-plugin-package-json/commit/3d0bd1e04b935d30e85823dcf8c8d682ea4ab8d2)), closes [#000](https://github.com/michaelfaith/eslint-plugin-package-json/issues/000)

### Features

- **no-redundant-publishConfig:** add new rule ([#1366](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1366)) ([8d3680c](https://github.com/michaelfaith/eslint-plugin-package-json/commit/8d3680c5fb0df0af37744cf86201163aee372bab)), closes [#1365](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1365)
- **no-redundant-publishConfig:** add new rule ([#1366](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1366)) ([8d3680c](https://github.com/michaelfaith/eslint-plugin-package-json/commit/8d3680c5fb0df0af37744cf86201163aee372bab)), closes [#1365](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1365)

## [0.64.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.63.0...v0.64.0) (2025-11-04)
## [0.64.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.63.0...v0.64.0) (2025-11-04)

### Features

- **bin-name-casing:** add new rule ([#1343](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1343)) ([0e10e87](https://github.com/michaelfaith/eslint-plugin-package-json/commit/0e10e875eb4cc5f680e154e6ea2333e5902d4c4c)), closes [#1346](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1346)
- **bin-name-casing:** add new rule ([#1343](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1343)) ([0e10e87](https://github.com/michaelfaith/eslint-plugin-package-json/commit/0e10e875eb4cc5f680e154e6ea2333e5902d4c4c)), closes [#1346](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1346)

## [0.63.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.62.0...v0.63.0) (2025-11-04)
## [0.63.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.62.0...v0.63.0) (2025-11-04)

### Features

- **restrict-private-properties:** add new rule ([#1336](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1336)) ([e1225cf](https://github.com/michaelfaith/eslint-plugin-package-json/commit/e1225cf991be2f3829cdddcae8b06cef8196f070)), closes [#1323](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1323)
- **restrict-private-properties:** add new rule ([#1336](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1336)) ([e1225cf](https://github.com/michaelfaith/eslint-plugin-package-json/commit/e1225cf991be2f3829cdddcae8b06cef8196f070)), closes [#1323](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1323)

## [0.62.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.61.0...v0.62.0) (2025-11-03)
## [0.62.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.61.0...v0.62.0) (2025-11-03)

### Features

- **scripts-name-casing:** add new rule ([#1344](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1344)) ([e735595](https://github.com/michaelfaith/eslint-plugin-package-json/commit/e735595537e6857c771eac12a1efcd55cb2d3564)), closes [#61](https://github.com/michaelfaith/eslint-plugin-package-json/issues/61)
- **scripts-name-casing:** add new rule ([#1344](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1344)) ([e735595](https://github.com/michaelfaith/eslint-plugin-package-json/commit/e735595537e6857c771eac12a1efcd55cb2d3564)), closes [#61](https://github.com/michaelfaith/eslint-plugin-package-json/issues/61)

## [0.61.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.60.0...v0.61.0) (2025-11-03)
## [0.61.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.60.0...v0.61.0) (2025-11-03)

### Features

- add new stylistic config ([#1342](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1342)) ([3d01cce](https://github.com/michaelfaith/eslint-plugin-package-json/commit/3d01cce99a1718a7485669c7b8cf6143a255b094)), closes [#1341](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1341)
- add new stylistic config ([#1342](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1342)) ([3d01cce](https://github.com/michaelfaith/eslint-plugin-package-json/commit/3d01cce99a1718a7485669c7b8cf6143a255b094)), closes [#1341](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1341)

## [0.60.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.59.1...v0.60.0) (2025-11-03)
## [0.60.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.59.1...v0.60.0) (2025-11-03)

### Features

- **valid-author:** create more precise reports ([#1337](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1337)) ([e79ff9a](https://github.com/michaelfaith/eslint-plugin-package-json/commit/e79ff9ac602d85bf999686b018de6ace3a7bee36)), closes [#000](https://github.com/michaelfaith/eslint-plugin-package-json/issues/000)
- **valid-author:** create more precise reports ([#1337](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1337)) ([e79ff9a](https://github.com/michaelfaith/eslint-plugin-package-json/commit/e79ff9ac602d85bf999686b018de6ace3a7bee36)), closes [#000](https://github.com/michaelfaith/eslint-plugin-package-json/issues/000)

## [0.59.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.59.0...v0.59.1) (2025-10-30)
## [0.59.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.59.0...v0.59.1) (2025-10-30)

### Bug Fixes

- **deps:** update dependency validate-npm-package-name to v7 ([#1353](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1353)) ([be9970a](https://github.com/michaelfaith/eslint-plugin-package-json/commit/be9970a18c73521906d1564ca461d94159e88807))
- **deps:** update dependency validate-npm-package-name to v7 ([#1353](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1353)) ([be9970a](https://github.com/michaelfaith/eslint-plugin-package-json/commit/be9970a18c73521906d1564ca461d94159e88807))

## [0.59.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.58.0...v0.59.0) (2025-10-25)
## [0.59.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.58.0...v0.59.0) (2025-10-25)

### Features

- **exports-subpaths-style:** add new rule ([#1328](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1328)) ([d1a82ed](https://github.com/michaelfaith/eslint-plugin-package-json/commit/d1a82edf78b7b4bd446018f1ea3bb77e1bc9c772)), closes [#1322](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1322)
- **exports-subpaths-style:** add new rule ([#1328](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1328)) ([d1a82ed](https://github.com/michaelfaith/eslint-plugin-package-json/commit/d1a82edf78b7b4bd446018f1ea3bb77e1bc9c772)), closes [#1322](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1322)

## [0.58.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.57.0...v0.58.0) (2025-10-22)
## [0.58.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.57.0...v0.58.0) (2025-10-22)

### Features

- mark `legacy-recommended` config deprecated ([#1331](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1331)) ([5e20411](https://github.com/michaelfaith/eslint-plugin-package-json/commit/5e204118f4b6ae4a50f9a50a1c2a64a5bf84a5a7)), closes [#1329](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1329) [#1253](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1253)
- mark `legacy-recommended` config deprecated ([#1331](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1331)) ([5e20411](https://github.com/michaelfaith/eslint-plugin-package-json/commit/5e204118f4b6ae4a50f9a50a1c2a64a5bf84a5a7)), closes [#1329](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1329) [#1253](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1253)

## [0.57.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.56.4...v0.57.0) (2025-10-16)
## [0.57.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.56.4...v0.57.0) (2025-10-16)

### Features

- add require-license rule ([#1302](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1302)) ([6d41e06](https://github.com/michaelfaith/eslint-plugin-package-json/commit/6d41e06dfd2eb89b026229d4045dcdae2cc29e70)), closes [#846](https://github.com/michaelfaith/eslint-plugin-package-json/issues/846)
- add require-license rule ([#1302](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1302)) ([6d41e06](https://github.com/michaelfaith/eslint-plugin-package-json/commit/6d41e06dfd2eb89b026229d4045dcdae2cc29e70)), closes [#846](https://github.com/michaelfaith/eslint-plugin-package-json/issues/846)

## [0.56.4](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.56.3...v0.56.4) (2025-10-14)
## [0.56.4](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.56.3...v0.56.4) (2025-10-14)

### Bug Fixes

- re-adopt jsonc-eslint-parser's RuleListener type ([#1319](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1319)) ([2c4c7c2](https://github.com/michaelfaith/eslint-plugin-package-json/commit/2c4c7c2591732f1b298e5e6eb279afe5f7d52cab)), closes [#000](https://github.com/michaelfaith/eslint-plugin-package-json/issues/000)
- re-adopt jsonc-eslint-parser's RuleListener type ([#1319](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1319)) ([2c4c7c2](https://github.com/michaelfaith/eslint-plugin-package-json/commit/2c4c7c2591732f1b298e5e6eb279afe5f7d52cab)), closes [#000](https://github.com/michaelfaith/eslint-plugin-package-json/issues/000)

## [0.56.3](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.56.2...v0.56.3) (2025-09-15)
## [0.56.3](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.56.2...v0.56.3) (2025-09-15)

### Bug Fixes

- **plugin:** update types to be compatible with `defineConfig` ([#1245](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1245)) ([861e5e1](https://github.com/michaelfaith/eslint-plugin-package-json/commit/861e5e129b3a5e3455b6b2a2a26d453086f20c14)), closes [#1242](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1242)
- **plugin:** update types to be compatible with `defineConfig` ([#1245](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1245)) ([861e5e1](https://github.com/michaelfaith/eslint-plugin-package-json/commit/861e5e129b3a5e3455b6b2a2a26d453086f20c14)), closes [#1242](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1242)

## [0.56.2](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.56.1...v0.56.2) (2025-09-04)
## [0.56.2](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.56.1...v0.56.2) (2025-09-04)

### Bug Fixes

- improve sort-collections docs and error messages ([#1250](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1250)) ([1864376](https://github.com/michaelfaith/eslint-plugin-package-json/commit/1864376039db3db690423051b0dd8a2104395aa4)), closes [#1243](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1243) [#1243](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1243)
- improve sort-collections docs and error messages ([#1250](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1250)) ([1864376](https://github.com/michaelfaith/eslint-plugin-package-json/commit/1864376039db3db690423051b0dd8a2104395aa4)), closes [#1243](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1243) [#1243](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1243)

## [0.56.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.56.0...v0.56.1) (2025-08-31)
## [0.56.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.56.0...v0.56.1) (2025-08-31)

### Bug Fixes

- **deps:** update dependency package-json-validator to ~0.30.0 ([#1241](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1241)) ([c3d247c](https://github.com/michaelfaith/eslint-plugin-package-json/commit/c3d247cc416d4bb0eee629fde3440224fe39eb59))
- **deps:** update dependency package-json-validator to ~0.30.0 ([#1241](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1241)) ([c3d247c](https://github.com/michaelfaith/eslint-plugin-package-json/commit/c3d247cc416d4bb0eee629fde3440224fe39eb59))

## [0.56.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.55.0...v0.56.0) (2025-08-25)
## [0.56.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.55.0...v0.56.0) (2025-08-25)

### Features

- **valid-directories:** add new rule for validating `directories` ([#1224](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1224)) ([b1cc676](https://github.com/michaelfaith/eslint-plugin-package-json/commit/b1cc6762f7e46162e4a6bf067dd29af2983462c8)), closes [#825](https://github.com/michaelfaith/eslint-plugin-package-json/issues/825)
- **valid-directories:** add new rule for validating `directories` ([#1224](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1224)) ([b1cc676](https://github.com/michaelfaith/eslint-plugin-package-json/commit/b1cc6762f7e46162e4a6bf067dd29af2983462c8)), closes [#825](https://github.com/michaelfaith/eslint-plugin-package-json/issues/825)

## [0.55.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.54.0...v0.55.0) (2025-08-22)
## [0.55.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.54.0...v0.55.0) (2025-08-22)

### Features

- add no-redundant-files to recommended ([#1232](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1232)) ([2a52f87](https://github.com/michaelfaith/eslint-plugin-package-json/commit/2a52f8797bff236f88232d139e2a9526c24e4b4c)), closes [#1231](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1231)
- add no-redundant-files to recommended ([#1232](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1232)) ([2a52f87](https://github.com/michaelfaith/eslint-plugin-package-json/commit/2a52f8797bff236f88232d139e2a9526c24e4b4c)), closes [#1231](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1231)

## [0.54.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.53.0...v0.54.0) (2025-08-15)
## [0.54.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.53.0...v0.54.0) (2025-08-15)

### Features

- **valid-exports:** add new rule for validating `exports` ([#1220](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1220)) ([2af10da](https://github.com/michaelfaith/eslint-plugin-package-json/commit/2af10dae3398832819c6dd37730ffef5ee3329b7)), closes [#1033](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1033)
- **valid-exports:** add new rule for validating `exports` ([#1220](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1220)) ([2af10da](https://github.com/michaelfaith/eslint-plugin-package-json/commit/2af10dae3398832819c6dd37730ffef5ee3329b7)), closes [#1033](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1033)

## [0.53.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.52.1...v0.53.0) (2025-08-13)
## [0.53.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.52.1...v0.53.0) (2025-08-13)

### Features

- add docs url to all rules ([#1218](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1218)) ([d456b13](https://github.com/michaelfaith/eslint-plugin-package-json/commit/d456b13d2c30e71d11294a315282859c66a4b1b7)), closes [#1217](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1217)
- add docs url to all rules ([#1218](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1218)) ([d456b13](https://github.com/michaelfaith/eslint-plugin-package-json/commit/d456b13d2c30e71d11294a315282859c66a4b1b7)), closes [#1217](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1217)

## [0.52.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.52.0...v0.52.1) (2025-08-07)
## [0.52.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.52.0...v0.52.1) (2025-08-07)

### Bug Fixes

- **sort-collections:** align sorting of scripts with `prettier-plugin-packagejson` ([#1203](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1203)) ([1f5c590](https://github.com/michaelfaith/eslint-plugin-package-json/commit/1f5c590adc846194766127ab962f8efa72942d06)), closes [#753](https://github.com/michaelfaith/eslint-plugin-package-json/issues/753)
- **sort-collections:** align sorting of scripts with `prettier-plugin-packagejson` ([#1203](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1203)) ([1f5c590](https://github.com/michaelfaith/eslint-plugin-package-json/commit/1f5c590adc846194766127ab962f8efa72942d06)), closes [#753](https://github.com/michaelfaith/eslint-plugin-package-json/issues/753)

## [0.52.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.51.0...v0.52.0) (2025-08-07)
## [0.52.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.51.0...v0.52.0) (2025-08-07)

### Features

- **valid-description:** add new rule for validating `description` ([#1204](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1204)) ([4acb265](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4acb26563c0cacb5834c8b53dae68fb291c0ffd1)), closes [#823](https://github.com/michaelfaith/eslint-plugin-package-json/issues/823)
- **valid-description:** add new rule for validating `description` ([#1204](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1204)) ([4acb265](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4acb26563c0cacb5834c8b53dae68fb291c0ffd1)), closes [#823](https://github.com/michaelfaith/eslint-plugin-package-json/issues/823)

## [0.51.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.50.0...v0.51.0) (2025-08-05)
## [0.51.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.50.0...v0.51.0) (2025-08-05)

### Features

- add `ignorePrivate` option to all `require-*` rules ([#1158](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1158)) ([055009b](https://github.com/michaelfaith/eslint-plugin-package-json/commit/055009bf864c9f8db153bf0c5bb9568d023abe12)), closes [#1092](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1092)
- add `ignorePrivate` option to all `require-*` rules ([#1158](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1158)) ([055009b](https://github.com/michaelfaith/eslint-plugin-package-json/commit/055009bf864c9f8db153bf0c5bb9568d023abe12)), closes [#1092](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1092)

## [0.50.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.49.0...v0.50.0) (2025-08-05)
## [0.50.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.49.0...v0.50.0) (2025-08-05)

### Features

- add new `require-` rules for `bugs`, `bundleDependencies`, `dependencies`, and more ([#1197](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1197)) ([0a06664](https://github.com/michaelfaith/eslint-plugin-package-json/commit/0a0666404d5659ea8eb8717516aa3c3b6374af26)), closes [#862](https://github.com/michaelfaith/eslint-plugin-package-json/issues/862) [#863](https://github.com/michaelfaith/eslint-plugin-package-json/issues/863) [#811](https://github.com/michaelfaith/eslint-plugin-package-json/issues/811) [#809](https://github.com/michaelfaith/eslint-plugin-package-json/issues/809) [#801](https://github.com/michaelfaith/eslint-plugin-package-json/issues/801) [#797](https://github.com/michaelfaith/eslint-plugin-package-json/issues/797)
- add new `require-` rules for `bugs`, `bundleDependencies`, `dependencies`, and more ([#1197](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1197)) ([0a06664](https://github.com/michaelfaith/eslint-plugin-package-json/commit/0a0666404d5659ea8eb8717516aa3c3b6374af26)), closes [#862](https://github.com/michaelfaith/eslint-plugin-package-json/issues/862) [#863](https://github.com/michaelfaith/eslint-plugin-package-json/issues/863) [#811](https://github.com/michaelfaith/eslint-plugin-package-json/issues/811) [#809](https://github.com/michaelfaith/eslint-plugin-package-json/issues/809) [#801](https://github.com/michaelfaith/eslint-plugin-package-json/issues/801) [#797](https://github.com/michaelfaith/eslint-plugin-package-json/issues/797)

## [0.49.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.48.0...v0.49.0) (2025-08-05)
## [0.49.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.48.0...v0.49.0) (2025-08-05)

### Features

- **valid-dependencies:** add new rule for validating dependencies ([#1196](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1196)) ([73af8e2](https://github.com/michaelfaith/eslint-plugin-package-json/commit/73af8e214d99df618d5d8c4eb9bfdfefc062ef84)), closes [#822](https://github.com/michaelfaith/eslint-plugin-package-json/issues/822) [#824](https://github.com/michaelfaith/eslint-plugin-package-json/issues/824) [#833](https://github.com/michaelfaith/eslint-plugin-package-json/issues/833) [#835](https://github.com/michaelfaith/eslint-plugin-package-json/issues/835)
- **valid-dependencies:** add new rule for validating dependencies ([#1196](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1196)) ([73af8e2](https://github.com/michaelfaith/eslint-plugin-package-json/commit/73af8e214d99df618d5d8c4eb9bfdfefc062ef84)), closes [#822](https://github.com/michaelfaith/eslint-plugin-package-json/issues/822) [#824](https://github.com/michaelfaith/eslint-plugin-package-json/issues/824) [#833](https://github.com/michaelfaith/eslint-plugin-package-json/issues/833) [#835](https://github.com/michaelfaith/eslint-plugin-package-json/issues/835)

## [0.48.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.47.1...v0.48.0) (2025-07-31)
## [0.48.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.47.1...v0.48.0) (2025-07-31)

### Features

- **valid-cpu:** add new rule for validating `cpu` ([#1192](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1192)) ([b52cd7c](https://github.com/michaelfaith/eslint-plugin-package-json/commit/b52cd7c3d4808d49ad99e0b8a82763e608f03550)), closes [#821](https://github.com/michaelfaith/eslint-plugin-package-json/issues/821)
- **valid-cpu:** add new rule for validating `cpu` ([#1192](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1192)) ([b52cd7c](https://github.com/michaelfaith/eslint-plugin-package-json/commit/b52cd7c3d4808d49ad99e0b8a82763e608f03550)), closes [#821](https://github.com/michaelfaith/eslint-plugin-package-json/issues/821)

## [0.47.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.47.0...v0.47.1) (2025-07-30)
## [0.47.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.47.0...v0.47.1) (2025-07-30)

### Bug Fixes

- **no-empty-fields:** don't throw error on empty object ([#1190](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1190)) ([8a9ba8a](https://github.com/michaelfaith/eslint-plugin-package-json/commit/8a9ba8acb1d68fd1040a008dfdb185b6908284a2)), closes [#1188](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1188)
- **no-empty-fields:** don't throw error on empty object ([#1190](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1190)) ([8a9ba8a](https://github.com/michaelfaith/eslint-plugin-package-json/commit/8a9ba8acb1d68fd1040a008dfdb185b6908284a2)), closes [#1188](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1188)

## [0.47.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.46.0...v0.47.0) (2025-07-25)
## [0.47.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.46.0...v0.47.0) (2025-07-25)

### Features

- **no-empty-fields:** Add `ignoreProperties` option ([#1186](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1186)) ([91e7156](https://github.com/michaelfaith/eslint-plugin-package-json/commit/91e7156d9f4569e8fee6f1124c4c1bb18ffdfbe0)), closes [#1182](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1182)
- **no-empty-fields:** Add `ignoreProperties` option ([#1186](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1186)) ([91e7156](https://github.com/michaelfaith/eslint-plugin-package-json/commit/91e7156d9f4569e8fee6f1124c4c1bb18ffdfbe0)), closes [#1182](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1182)

## [0.46.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.45.2...v0.46.0) (2025-07-24)
## [0.46.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.45.2...v0.46.0) (2025-07-24)

### Features

- **valid-config:** add new rule for validating `config` ([#1179](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1179)) ([b71de96](https://github.com/michaelfaith/eslint-plugin-package-json/commit/b71de96a2a79a91d177ee0d734dc5f5d1d8e5b3b)), closes [#820](https://github.com/michaelfaith/eslint-plugin-package-json/issues/820)
- **valid-config:** add new rule for validating `config` ([#1179](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1179)) ([b71de96](https://github.com/michaelfaith/eslint-plugin-package-json/commit/b71de96a2a79a91d177ee0d734dc5f5d1d8e5b3b)), closes [#820](https://github.com/michaelfaith/eslint-plugin-package-json/issues/820)

## [0.45.2](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.45.1...v0.45.2) (2025-07-24)
## [0.45.2](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.45.1...v0.45.2) (2025-07-24)

### Bug Fixes

- **deps:** update dependency package-json-validator to ~0.23.0 ([#1183](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1183)) ([fbc5f29](https://github.com/michaelfaith/eslint-plugin-package-json/commit/fbc5f298a63a4ce58d1311502bbea9a0593173d1))
- **deps:** update dependency package-json-validator to ~0.23.0 ([#1183](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1183)) ([fbc5f29](https://github.com/michaelfaith/eslint-plugin-package-json/commit/fbc5f298a63a4ce58d1311502bbea9a0593173d1))

## [0.45.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.45.0...v0.45.1) (2025-07-18)
## [0.45.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.45.0...v0.45.1) (2025-07-18)

### Bug Fixes

- **valid-repository-directory:** use correct path separator when on windows ([#1177](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1177)) ([0688419](https://github.com/michaelfaith/eslint-plugin-package-json/commit/06884197a028a258c31db0104d8db1dc86f53345)), closes [#1175](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1175)
- **valid-repository-directory:** use correct path separator when on windows ([#1177](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1177)) ([0688419](https://github.com/michaelfaith/eslint-plugin-package-json/commit/06884197a028a258c31db0104d8db1dc86f53345)), closes [#1175](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1175)

## [0.45.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.44.1...v0.45.0) (2025-07-17)
## [0.45.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.44.1...v0.45.0) (2025-07-17)

### Features

- **valid-license:** add new rule for validating `license` ([#1174](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1174)) ([df450a1](https://github.com/michaelfaith/eslint-plugin-package-json/commit/df450a121067793af25890eb15e4120911a8cfa7)), closes [#830](https://github.com/michaelfaith/eslint-plugin-package-json/issues/830)
- **valid-license:** add new rule for validating `license` ([#1174](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1174)) ([df450a1](https://github.com/michaelfaith/eslint-plugin-package-json/commit/df450a121067793af25890eb15e4120911a8cfa7)), closes [#830](https://github.com/michaelfaith/eslint-plugin-package-json/issues/830)

## [0.44.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.44.0...v0.44.1) (2025-07-10)
## [0.44.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.44.0...v0.44.1) (2025-07-10)

### Bug Fixes

- **deps:** update dependency package-json-validator to ~0.20.0 ([#1170](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1170)) ([941cf73](https://github.com/michaelfaith/eslint-plugin-package-json/commit/941cf734557db103da915d36de5adc18083a22a1))
- **deps:** update dependency package-json-validator to ~0.20.0 ([#1170](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1170)) ([941cf73](https://github.com/michaelfaith/eslint-plugin-package-json/commit/941cf734557db103da915d36de5adc18083a22a1))

## [0.44.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.43.4...v0.44.0) (2025-07-09)
## [0.44.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.43.4...v0.44.0) (2025-07-09)

### Features

- **valid-bundleDependencies:** add new rule for validating `bundleDependencies` ([#1148](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1148)) ([ee44973](https://github.com/michaelfaith/eslint-plugin-package-json/commit/ee449730ece778037a4d1ea7aa2d2ec83081a1cb)), closes [#819](https://github.com/michaelfaith/eslint-plugin-package-json/issues/819)
- **valid-bundleDependencies:** add new rule for validating `bundleDependencies` ([#1148](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1148)) ([ee44973](https://github.com/michaelfaith/eslint-plugin-package-json/commit/ee449730ece778037a4d1ea7aa2d2ec83081a1cb)), closes [#819](https://github.com/michaelfaith/eslint-plugin-package-json/issues/819)

## [0.43.4](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.43.3...v0.43.4) (2025-07-09)
## [0.43.4](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.43.3...v0.43.4) (2025-07-09)

### Bug Fixes

- **deps:** update dependency package-json-validator to ~0.19.0 ([#1167](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1167)) ([9c72efd](https://github.com/michaelfaith/eslint-plugin-package-json/commit/9c72efd89801c61c22b92834fa3bbac0119a0fd4))
- **deps:** update dependency package-json-validator to ~0.19.0 ([#1167](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1167)) ([9c72efd](https://github.com/michaelfaith/eslint-plugin-package-json/commit/9c72efd89801c61c22b92834fa3bbac0119a0fd4))

## [0.43.3](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.43.2...v0.43.3) (2025-07-08)
## [0.43.3](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.43.2...v0.43.3) (2025-07-08)

### Bug Fixes

- **deps:** update dependency @altano/repository-tools to v2 ([#1164](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1164)) ([0c54bc9](https://github.com/michaelfaith/eslint-plugin-package-json/commit/0c54bc913a92c22dcfa43626e4c8ee44b527af51))
- **deps:** update dependency @altano/repository-tools to v2 ([#1164](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1164)) ([0c54bc9](https://github.com/michaelfaith/eslint-plugin-package-json/commit/0c54bc913a92c22dcfa43626e4c8ee44b527af51))

## [0.43.2](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.43.1...v0.43.2) (2025-07-04)
## [0.43.2](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.43.1...v0.43.2) (2025-07-04)

### Bug Fixes

- **deps:** update dependency package-json-validator to ~0.18.0 ([#1160](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1160)) ([dfebe75](https://github.com/michaelfaith/eslint-plugin-package-json/commit/dfebe75f2fa7778ba188580a0d33ce0d8e151413))
- **deps:** update dependency package-json-validator to ~0.18.0 ([#1160](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1160)) ([dfebe75](https://github.com/michaelfaith/eslint-plugin-package-json/commit/dfebe75f2fa7778ba188580a0d33ce0d8e151413))

## [0.43.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.43.0...v0.43.1) (2025-07-03)
## [0.43.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.43.0...v0.43.1) (2025-07-03)

### Bug Fixes

- disallow extra properties in rule options ([#1156](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1156)) ([4186e96](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4186e960c17a5397ac916184fc4341f9b26fc3d0))
- disallow extra properties in rule options ([#1156](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1156)) ([4186e96](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4186e960c17a5397ac916184fc4341f9b26fc3d0))

## [0.43.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.42.1...v0.43.0) (2025-07-02)
## [0.43.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.42.1...v0.43.0) (2025-07-02)

### Features

- **valid-scripts:** add new rule for validating scripts ([#1138](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1138)) ([99cc2a5](https://github.com/michaelfaith/eslint-plugin-package-json/commit/99cc2a5d069bfff53885f0717b8a635767cb2c19)), closes [#839](https://github.com/michaelfaith/eslint-plugin-package-json/issues/839)
- **valid-scripts:** add new rule for validating scripts ([#1138](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1138)) ([99cc2a5](https://github.com/michaelfaith/eslint-plugin-package-json/commit/99cc2a5d069bfff53885f0717b8a635767cb2c19)), closes [#839](https://github.com/michaelfaith/eslint-plugin-package-json/issues/839)

## [0.42.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.42.0...v0.42.1) (2025-07-01)
## [0.42.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.42.0...v0.42.1) (2025-07-01)

### Bug Fixes

- **deps:** update dependency package-json-validator to ~0.17.0 ([#1152](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1152)) ([16239d0](https://github.com/michaelfaith/eslint-plugin-package-json/commit/16239d084c245836549071a4e8ac2879b4f53f3e))
- **deps:** update dependency package-json-validator to ~0.17.0 ([#1152](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1152)) ([16239d0](https://github.com/michaelfaith/eslint-plugin-package-json/commit/16239d084c245836549071a4e8ac2879b4f53f3e))

## [0.42.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.41.0...v0.42.0) (2025-06-25)
## [0.42.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.41.0...v0.42.0) (2025-06-25)

### Features

- remove deprecated `valid-package-def` rule ([#1111](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1111)) ([946a585](https://github.com/michaelfaith/eslint-plugin-package-json/commit/946a585c2c9344ac227463cf234714fc204f1746)), closes [#1110](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1110) [#711](https://github.com/michaelfaith/eslint-plugin-package-json/issues/711)
- remove deprecated `valid-package-def` rule ([#1111](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1111)) ([946a585](https://github.com/michaelfaith/eslint-plugin-package-json/commit/946a585c2c9344ac227463cf234714fc204f1746)), closes [#1110](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1110) [#711](https://github.com/michaelfaith/eslint-plugin-package-json/issues/711)

## [0.41.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.40.5...v0.41.0) (2025-06-24)
## [0.41.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.40.5...v0.41.0) (2025-06-24)

### Features

- **valid-type:** add new rule ([#1120](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1120)) ([7425f27](https://github.com/michaelfaith/eslint-plugin-package-json/commit/7425f2796560e94420a85fa6494996cb052c06c4)), closes [#842](https://github.com/michaelfaith/eslint-plugin-package-json/issues/842)
- **valid-type:** add new rule ([#1120](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1120)) ([7425f27](https://github.com/michaelfaith/eslint-plugin-package-json/commit/7425f2796560e94420a85fa6494996cb052c06c4)), closes [#842](https://github.com/michaelfaith/eslint-plugin-package-json/issues/842)

## [0.40.5](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.40.4...v0.40.5) (2025-06-23)
## [0.40.5](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.40.4...v0.40.5) (2025-06-23)

### Bug Fixes

- **deps:** update dependency package-json-validator to ~0.16.0 ([#1135](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1135)) ([4a4a2a0](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4a4a2a07fdfef6b1869a51824a6697bbb2c34ecb))
- **deps:** update dependency package-json-validator to ~0.16.0 ([#1135](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1135)) ([4a4a2a0](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4a4a2a07fdfef6b1869a51824a6697bbb2c34ecb))

## [0.40.4](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.40.3...v0.40.4) (2025-06-20)
## [0.40.4](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.40.3...v0.40.4) (2025-06-20)

### Bug Fixes

- **deps:** update dependency package-json-validator to ~0.15.0 ([#1131](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1131)) ([4bf7d9c](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4bf7d9cd091faf9ac0fb286b5968d6417328c79c))
- **deps:** update dependency package-json-validator to ~0.15.0 ([#1131](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1131)) ([4bf7d9c](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4bf7d9cd091faf9ac0fb286b5968d6417328c79c))

## [0.40.3](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.40.2...v0.40.3) (2025-06-19)
## [0.40.3](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.40.2...v0.40.3) (2025-06-19)

### Bug Fixes

- **deps:** update dependency eslint-fix-utils to ^0.4.0 ([#1130](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1130)) ([b66db8c](https://github.com/michaelfaith/eslint-plugin-package-json/commit/b66db8c584f2b90677505c99840b91918e785ae8))
- **deps:** update dependency eslint-fix-utils to ^0.4.0 ([#1130](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1130)) ([b66db8c](https://github.com/michaelfaith/eslint-plugin-package-json/commit/b66db8c584f2b90677505c99840b91918e785ae8))

## [0.40.2](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.40.1...v0.40.2) (2025-06-19)
## [0.40.2](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.40.1...v0.40.2) (2025-06-19)

### Bug Fixes

- **deps:** update dependency package-json-validator to ~0.14.0 ([#1125](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1125)) ([5f61f89](https://github.com/michaelfaith/eslint-plugin-package-json/commit/5f61f8951ec3a8697f9a17a722da3d8bae499a09))
- **deps:** update dependency package-json-validator to ~0.14.0 ([#1125](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1125)) ([5f61f89](https://github.com/michaelfaith/eslint-plugin-package-json/commit/5f61f8951ec3a8697f9a17a722da3d8bae499a09))

## [0.40.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.40.0...v0.40.1) (2025-06-18)
## [0.40.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.40.0...v0.40.1) (2025-06-18)

### Bug Fixes

- **deps:** update dependency eslint-fix-utils to ^0.3.0 ([#1124](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1124)) ([1e30861](https://github.com/michaelfaith/eslint-plugin-package-json/commit/1e3086136f2449e0be6c4397af2de15287899da0))
- **deps:** update dependency eslint-fix-utils to ^0.3.0 ([#1124](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1124)) ([1e30861](https://github.com/michaelfaith/eslint-plugin-package-json/commit/1e3086136f2449e0be6c4397af2de15287899da0))

## [0.40.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.39.2...v0.40.0) (2025-06-16)
## [0.40.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.39.2...v0.40.0) (2025-06-16)

### Features

- **valid-bin:** add option for enforcing kebab-case ([#1113](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1113)) ([0024a4e](https://github.com/michaelfaith/eslint-plugin-package-json/commit/0024a4e42c70684b81e942a9aaeace0322c02fef)), closes [#1081](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1081)
- **valid-bin:** add option for enforcing kebab-case ([#1113](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1113)) ([0024a4e](https://github.com/michaelfaith/eslint-plugin-package-json/commit/0024a4e42c70684b81e942a9aaeace0322c02fef)), closes [#1081](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1081)

## [0.39.2](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.39.1...v0.39.2) (2025-06-15)
## [0.39.2](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.39.1...v0.39.2) (2025-06-15)

### Bug Fixes

- **deps:** update dependency detect-newline to v4 ([#875](https://github.com/michaelfaith/eslint-plugin-package-json/issues/875)) ([26c08d9](https://github.com/michaelfaith/eslint-plugin-package-json/commit/26c08d905a90729c011f3ff77d9e3784ad41cb7b))
- **deps:** update dependency detect-newline to v4 ([#875](https://github.com/michaelfaith/eslint-plugin-package-json/issues/875)) ([26c08d9](https://github.com/michaelfaith/eslint-plugin-package-json/commit/26c08d905a90729c011f3ff77d9e3784ad41cb7b))

## [0.39.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.39.0...v0.39.1) (2025-06-15)
## [0.39.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.39.0...v0.39.1) (2025-06-15)

### Bug Fixes

- **deps:** update dependency @altano/repository-tools to v1 ([#1006](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1006)) ([da63ce3](https://github.com/michaelfaith/eslint-plugin-package-json/commit/da63ce37654652690aa2bc3ea2a042a3ac7ff465))
- **deps:** update dependency @altano/repository-tools to v1 ([#1006](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1006)) ([da63ce3](https://github.com/michaelfaith/eslint-plugin-package-json/commit/da63ce37654652690aa2bc3ea2a042a3ac7ff465))

## [0.39.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.38.1...v0.39.0) (2025-06-13)
## [0.39.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.38.1...v0.39.0) (2025-06-13)

### Features

- deprecate `valid-local-dependency` ([#1107](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1107)) ([4efea70](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4efea705124a31a35ba9e10e3bb0ef79bf442fab)), closes [#1096](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1096)
- deprecate `valid-local-dependency` ([#1107](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1107)) ([4efea70](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4efea705124a31a35ba9e10e3bb0ef79bf442fab)), closes [#1096](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1096)

## [0.38.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.38.0...v0.38.1) (2025-06-13)
## [0.38.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.38.0...v0.38.1) (2025-06-13)

### Bug Fixes

- **valid-local-dependency:** don't flag archives as invalid ([#1109](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1109)) ([3d89865](https://github.com/michaelfaith/eslint-plugin-package-json/commit/3d89865bba6e3ecab02576cde131336a7dc8c169)), closes [#1086](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1086)
- **valid-local-dependency:** don't flag archives as invalid ([#1109](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1109)) ([3d89865](https://github.com/michaelfaith/eslint-plugin-package-json/commit/3d89865bba6e3ecab02576cde131336a7dc8c169)), closes [#1086](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1086)

## [0.38.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.37.0...v0.38.0) (2025-06-13)
## [0.38.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.37.0...v0.38.0) (2025-06-13)

### Features

- add `valid-author` rule ([#1079](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1079)) ([b8e8b40](https://github.com/michaelfaith/eslint-plugin-package-json/commit/b8e8b40065a0aa0bfa9e38697ab5fe3241b7d6d7)), closes [#840](https://github.com/michaelfaith/eslint-plugin-package-json/issues/840)
- add `valid-author` rule ([#1079](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1079)) ([b8e8b40](https://github.com/michaelfaith/eslint-plugin-package-json/commit/b8e8b40065a0aa0bfa9e38697ab5fe3241b7d6d7)), closes [#840](https://github.com/michaelfaith/eslint-plugin-package-json/issues/840)

## [0.37.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.36.0...v0.37.0) (2025-06-12)
## [0.37.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.36.0...v0.37.0) (2025-06-12)

### Features

- **valid-bin:** add new rule for validating bin ([#1082](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1082)) ([e9cc86e](https://github.com/michaelfaith/eslint-plugin-package-json/commit/e9cc86ec5827a4374f81886865b578f40823c5b8)), closes [#818](https://github.com/michaelfaith/eslint-plugin-package-json/issues/818) [#1077](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1077)
- **valid-bin:** add new rule for validating bin ([#1082](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1082)) ([e9cc86e](https://github.com/michaelfaith/eslint-plugin-package-json/commit/e9cc86ec5827a4374f81886865b578f40823c5b8)), closes [#818](https://github.com/michaelfaith/eslint-plugin-package-json/issues/818) [#1077](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1077)

## [0.36.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.35.1...v0.36.0) (2025-06-11)
## [0.36.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.35.1...v0.36.0) (2025-06-11)

### Features

- migrate to ESM-only ([#1100](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1100)) ([623f162](https://github.com/michaelfaith/eslint-plugin-package-json/commit/623f162daa726a717c3ad48c1a777c3be7c404b0)), closes [#1080](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1080)
- migrate to ESM-only ([#1100](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1100)) ([623f162](https://github.com/michaelfaith/eslint-plugin-package-json/commit/623f162daa726a717c3ad48c1a777c3be7c404b0)), closes [#1080](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1080)

## [0.35.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.35.0...v0.35.1) (2025-06-10)
## [0.35.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.35.0...v0.35.1) (2025-06-10)

### Bug Fixes

- **deps:** update dependency detect-indent to v7 ([#874](https://github.com/michaelfaith/eslint-plugin-package-json/issues/874)) ([65300dc](https://github.com/michaelfaith/eslint-plugin-package-json/commit/65300dc30dfdc79ab789a144f251f0b8ba96ea22))
- **deps:** update dependency detect-indent to v7 ([#874](https://github.com/michaelfaith/eslint-plugin-package-json/issues/874)) ([65300dc](https://github.com/michaelfaith/eslint-plugin-package-json/commit/65300dc30dfdc79ab789a144f251f0b8ba96ea22))

## [0.35.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.34.0...v0.35.0) (2025-06-10)
## [0.35.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.34.0...v0.35.0) (2025-06-10)

### Features

- remove support for node 18 ([#1097](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1097)) ([257659a](https://github.com/michaelfaith/eslint-plugin-package-json/commit/257659af4fda63e2143d1ab250546dd3cb0932e7)), closes [#1074](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1074)
- remove support for node 18 ([#1097](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1097)) ([257659a](https://github.com/michaelfaith/eslint-plugin-package-json/commit/257659af4fda63e2143d1ab250546dd3cb0932e7)), closes [#1074](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1074)

## [0.34.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.33.2...v0.34.0) (2025-06-10)
## [0.34.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.33.2...v0.34.0) (2025-06-10)

### Features

- **valid-package-definition:** add ignoreProperties option ([#1077](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1077)) ([530e343](https://github.com/michaelfaith/eslint-plugin-package-json/commit/530e3430f87f21c9fadd4d511097d20e26f7190f)), closes [#1076](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1076)
- **valid-package-definition:** add ignoreProperties option ([#1077](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1077)) ([530e343](https://github.com/michaelfaith/eslint-plugin-package-json/commit/530e3430f87f21c9fadd4d511097d20e26f7190f)), closes [#1076](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1076)

## [0.33.2](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.33.1...v0.33.2) (2025-06-01)
## [0.33.2](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.33.1...v0.33.2) (2025-06-01)

### Bug Fixes

- prevent `no-redundant-files` crash with wildcard and `main` field ([#1078](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1078)) ([ad4f95f](https://github.com/michaelfaith/eslint-plugin-package-json/commit/ad4f95f382bce8d5d0ecc79e4242596dc3eec771)), closes [#1066](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1066)
- prevent `no-redundant-files` crash with wildcard and `main` field ([#1078](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1078)) ([ad4f95f](https://github.com/michaelfaith/eslint-plugin-package-json/commit/ad4f95f382bce8d5d0ecc79e4242596dc3eec771)), closes [#1066](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1066)

## [0.33.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.33.0...v0.33.1) (2025-06-01)
## [0.33.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.33.0...v0.33.1) (2025-06-01)

### Bug Fixes

- add CHANGELOG to package ([#1075](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1075)) ([eb13030](https://github.com/michaelfaith/eslint-plugin-package-json/commit/eb130302b6dfcc456dfeaf49fdfd61bd4fa495d1)), closes [#1070](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1070)
- add CHANGELOG to package ([#1075](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1075)) ([eb13030](https://github.com/michaelfaith/eslint-plugin-package-json/commit/eb130302b6dfcc456dfeaf49fdfd61bd4fa495d1)), closes [#1070](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1070)

## [0.33.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.32.0...v0.33.0) (2025-05-31)
## [0.33.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.32.0...v0.33.0) (2025-05-31)

### Features

- add `require-type` rule ([#1065](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1065)) ([9c092be](https://github.com/michaelfaith/eslint-plugin-package-json/commit/9c092beb546407c4b8b43426058c56696a88b7c3)), closes [#1032](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1032)
- add `require-type` rule ([#1065](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1065)) ([9c092be](https://github.com/michaelfaith/eslint-plugin-package-json/commit/9c092beb546407c4b8b43426058c56696a88b7c3)), closes [#1032](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1032)

## [0.32.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.31.0...v0.32.0) (2025-05-31)
## [0.32.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.31.0...v0.32.0) (2025-05-31)

No meaningful change.
CI error.

## [0.31.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.30.0...v0.31.0) (2025-04-26)
## [0.31.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.30.0...v0.31.0) (2025-04-26)

### Features

- add require-description rule ([#1024](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1024)) ([0c00c62](https://github.com/michaelfaith/eslint-plugin-package-json/commit/0c00c62cc3b68ff9eae8d3f3bf20d8b4fbbb3926)), closes [#864](https://github.com/michaelfaith/eslint-plugin-package-json/issues/864)
- add require-description rule ([#1024](https://github.com/michaelfaith/eslint-plugin-package-json/issues/1024)) ([0c00c62](https://github.com/michaelfaith/eslint-plugin-package-json/commit/0c00c62cc3b68ff9eae8d3f3bf20d8b4fbbb3926)), closes [#864](https://github.com/michaelfaith/eslint-plugin-package-json/issues/864)

## [0.30.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.29.1...v0.30.0) (2025-04-22)
## [0.30.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.29.1...v0.30.0) (2025-04-22)

### Features

- new `restrict-dependency-ranges` rule ([#998](https://github.com/michaelfaith/eslint-plugin-package-json/issues/998)) ([f2d1070](https://github.com/michaelfaith/eslint-plugin-package-json/commit/f2d1070433a488a8bd34ad2a40a3337b218bc358)), closes [#959](https://github.com/michaelfaith/eslint-plugin-package-json/issues/959) [#959](https://github.com/michaelfaith/eslint-plugin-package-json/issues/959)
- new `restrict-dependency-ranges` rule ([#998](https://github.com/michaelfaith/eslint-plugin-package-json/issues/998)) ([f2d1070](https://github.com/michaelfaith/eslint-plugin-package-json/commit/f2d1070433a488a8bd34ad2a40a3337b218bc358)), closes [#959](https://github.com/michaelfaith/eslint-plugin-package-json/issues/959) [#959](https://github.com/michaelfaith/eslint-plugin-package-json/issues/959)

## [0.29.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.29.0...v0.29.1) (2025-04-09)
## [0.29.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.29.0...v0.29.1) (2025-04-09)

### Bug Fixes

- bump to create-typescript-app@2 with transitions action ([#993](https://github.com/michaelfaith/eslint-plugin-package-json/issues/993)) ([5b5c298](https://github.com/michaelfaith/eslint-plugin-package-json/commit/5b5c2989dda36b43e85a14056120e863ef4fec3f)), closes [#969](https://github.com/michaelfaith/eslint-plugin-package-json/issues/969)
- bump to create-typescript-app@2 with transitions action ([#993](https://github.com/michaelfaith/eslint-plugin-package-json/issues/993)) ([5b5c298](https://github.com/michaelfaith/eslint-plugin-package-json/commit/5b5c2989dda36b43e85a14056120e863ef4fec3f)), closes [#969](https://github.com/michaelfaith/eslint-plugin-package-json/issues/969)

## [0.29.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.28.0...v0.29.0) (2025-03-17)
## [0.29.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.28.0...v0.29.0) (2025-03-17)

### Features

- **require-types:** add new rule ([#958](https://github.com/michaelfaith/eslint-plugin-package-json/issues/958)) ([63305af](https://github.com/michaelfaith/eslint-plugin-package-json/commit/63305afcac6fa57030b13de2ae9f26c108c979c0)), closes [#816](https://github.com/michaelfaith/eslint-plugin-package-json/issues/816) [#816](https://github.com/michaelfaith/eslint-plugin-package-json/issues/816)
- **require-types:** add new rule ([#958](https://github.com/michaelfaith/eslint-plugin-package-json/issues/958)) ([63305af](https://github.com/michaelfaith/eslint-plugin-package-json/commit/63305afcac6fa57030b13de2ae9f26c108c979c0)), closes [#816](https://github.com/michaelfaith/eslint-plugin-package-json/issues/816) [#816](https://github.com/michaelfaith/eslint-plugin-package-json/issues/816)

## [0.28.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.27.0...v0.28.0) (2025-03-17)
## [0.28.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.27.0...v0.28.0) (2025-03-17)

### Features

- **require-engines:** add new rule ([#954](https://github.com/michaelfaith/eslint-plugin-package-json/issues/954)) ([9093b28](https://github.com/michaelfaith/eslint-plugin-package-json/commit/9093b280c77770512ac88631e4903e17d5275bec)), closes [#868](https://github.com/michaelfaith/eslint-plugin-package-json/issues/868)
- **require-engines:** add new rule ([#954](https://github.com/michaelfaith/eslint-plugin-package-json/issues/954)) ([9093b28](https://github.com/michaelfaith/eslint-plugin-package-json/commit/9093b280c77770512ac88631e4903e17d5275bec)), closes [#868](https://github.com/michaelfaith/eslint-plugin-package-json/issues/868)

## [0.27.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.26.4...v0.27.0) (2025-03-17)
## [0.27.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.26.4...v0.27.0) (2025-03-17)

### Features

- empty feature commit to trigger new minor version ([b6b58d4](https://github.com/michaelfaith/eslint-plugin-package-json/commit/b6b58d46da07dd5f1a51e5b2c71a10803863b113))
- empty feature commit to trigger new minor version ([b6b58d4](https://github.com/michaelfaith/eslint-plugin-package-json/commit/b6b58d46da07dd5f1a51e5b2c71a10803863b113))

## [0.26.4](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.26.3...v0.26.4) (2025-03-17)
## [0.26.4](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.26.3...v0.26.4) (2025-03-17)

## [0.26.3](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.26.2...v0.26.3) (2025-03-07)
## [0.26.3](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.26.2...v0.26.3) (2025-03-07)

### Bug Fixes

- **deps:** update dependency sort-package-json to v3 ([#939](https://github.com/michaelfaith/eslint-plugin-package-json/issues/939)) ([a61e725](https://github.com/michaelfaith/eslint-plugin-package-json/commit/a61e7255f5f0fe70b2c190b38f76d684a9d3e37c))
- **deps:** update dependency sort-package-json to v3 ([#939](https://github.com/michaelfaith/eslint-plugin-package-json/issues/939)) ([a61e725](https://github.com/michaelfaith/eslint-plugin-package-json/commit/a61e7255f5f0fe70b2c190b38f76d684a9d3e37c))

## [0.26.2](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.26.1...v0.26.2) (2025-03-04)
## [0.26.2](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.26.1...v0.26.2) (2025-03-04)

### Bug Fixes

- **deps:** update dependency sort-package-json to v2.15.1 ([#933](https://github.com/michaelfaith/eslint-plugin-package-json/issues/933)) ([f3a8169](https://github.com/michaelfaith/eslint-plugin-package-json/commit/f3a8169113d25f3be69be2a6a027bd74ea3c8022))
- **deps:** update dependency sort-package-json to v2.15.1 ([#933](https://github.com/michaelfaith/eslint-plugin-package-json/issues/933)) ([f3a8169](https://github.com/michaelfaith/eslint-plugin-package-json/commit/f3a8169113d25f3be69be2a6a027bd74ea3c8022))

## [0.26.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.26.0...v0.26.1) (2025-03-02)
## [0.26.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.26.0...v0.26.1) (2025-03-02)

### Bug Fixes

- **deps:** update dependency sort-package-json to v2.15.0 ([#925](https://github.com/michaelfaith/eslint-plugin-package-json/issues/925)) ([3ce4286](https://github.com/michaelfaith/eslint-plugin-package-json/commit/3ce4286442f45c74d09dcc60e040bafb879a75f2))
- **deps:** update dependency sort-package-json to v2.15.0 ([#925](https://github.com/michaelfaith/eslint-plugin-package-json/issues/925)) ([3ce4286](https://github.com/michaelfaith/eslint-plugin-package-json/commit/3ce4286442f45c74d09dcc60e040bafb879a75f2))

## [0.26.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.25.0...v0.26.0) (2025-02-10)
## [0.26.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.25.0...v0.26.0) (2025-02-10)

### Features

- **require-files:** add require-files rule ([#887](https://github.com/michaelfaith/eslint-plugin-package-json/issues/887)) ([4de33de](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4de33de2715579c0d217609cd576d1b3b843d457)), closes [#803](https://github.com/michaelfaith/eslint-plugin-package-json/issues/803)
- **require-files:** add require-files rule ([#887](https://github.com/michaelfaith/eslint-plugin-package-json/issues/887)) ([4de33de](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4de33de2715579c0d217609cd576d1b3b843d457)), closes [#803](https://github.com/michaelfaith/eslint-plugin-package-json/issues/803)

## [0.25.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.24.0...v0.25.0) (2025-02-09)
## [0.25.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.24.0...v0.25.0) (2025-02-09)

### Features

- **require-keywords:** add require-keywords rule ([#884](https://github.com/michaelfaith/eslint-plugin-package-json/issues/884)) ([99237f0](https://github.com/michaelfaith/eslint-plugin-package-json/commit/99237f0dc5902bda417345cba681f23a328c5bbe)), closes [#866](https://github.com/michaelfaith/eslint-plugin-package-json/issues/866)
- **require-keywords:** add require-keywords rule ([#884](https://github.com/michaelfaith/eslint-plugin-package-json/issues/884)) ([99237f0](https://github.com/michaelfaith/eslint-plugin-package-json/commit/99237f0dc5902bda417345cba681f23a328c5bbe)), closes [#866](https://github.com/michaelfaith/eslint-plugin-package-json/issues/866)

## [0.24.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.23.1...v0.24.0) (2025-02-08)
## [0.24.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.23.1...v0.24.0) (2025-02-08)

### Features

- **require-name:** add require-name rule ([#883](https://github.com/michaelfaith/eslint-plugin-package-json/issues/883)) ([3a82dd8](https://github.com/michaelfaith/eslint-plugin-package-json/commit/3a82dd82d14b6bc1aaa72cfbc2e68aeb282ce18a)), closes [#808](https://github.com/michaelfaith/eslint-plugin-package-json/issues/808)
- **require-name:** add require-name rule ([#883](https://github.com/michaelfaith/eslint-plugin-package-json/issues/883)) ([3a82dd8](https://github.com/michaelfaith/eslint-plugin-package-json/commit/3a82dd82d14b6bc1aaa72cfbc2e68aeb282ce18a)), closes [#808](https://github.com/michaelfaith/eslint-plugin-package-json/issues/808)

## [0.23.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.23.0...v0.23.1) (2025-02-07)
## [0.23.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.23.0...v0.23.1) (2025-02-07)

### Bug Fixes

- **deps:** update dependency semver to v7.7.1 ([#880](https://github.com/michaelfaith/eslint-plugin-package-json/issues/880)) ([152cfc1](https://github.com/michaelfaith/eslint-plugin-package-json/commit/152cfc10e9cc9e34803e609ec3b12855395093c6))
- **deps:** update dependency semver to v7.7.1 ([#880](https://github.com/michaelfaith/eslint-plugin-package-json/issues/880)) ([152cfc1](https://github.com/michaelfaith/eslint-plugin-package-json/commit/152cfc10e9cc9e34803e609ec3b12855395093c6))

## [0.23.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.22.0...v0.23.0) (2025-02-04)
## [0.23.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.22.0...v0.23.0) (2025-02-04)

### Features

- **require-version:** add require-version rule ([#861](https://github.com/michaelfaith/eslint-plugin-package-json/issues/861)) ([848377d](https://github.com/michaelfaith/eslint-plugin-package-json/commit/848377dea379ed23d22d8fc5acd2e84c472ebb1b))
- **require-version:** add require-version rule ([#861](https://github.com/michaelfaith/eslint-plugin-package-json/issues/861)) ([848377d](https://github.com/michaelfaith/eslint-plugin-package-json/commit/848377dea379ed23d22d8fc5acd2e84c472ebb1b))

## [0.22.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.21.1...v0.22.0) (2025-02-03)
## [0.22.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.21.1...v0.22.0) (2025-02-03)

### Features

- **require-author:** add new `require-author` rule ([#851](https://github.com/michaelfaith/eslint-plugin-package-json/issues/851)) ([cde68da](https://github.com/michaelfaith/eslint-plugin-package-json/commit/cde68da27bf87d711a8fb6f90df9f99f7bdb1512)), closes [#795](https://github.com/michaelfaith/eslint-plugin-package-json/issues/795)
- **require-author:** add new `require-author` rule ([#851](https://github.com/michaelfaith/eslint-plugin-package-json/issues/851)) ([cde68da](https://github.com/michaelfaith/eslint-plugin-package-json/commit/cde68da27bf87d711a8fb6f90df9f99f7bdb1512)), closes [#795](https://github.com/michaelfaith/eslint-plugin-package-json/issues/795)

## [0.21.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.21.0...v0.21.1) (2025-01-24)
## [0.21.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.21.0...v0.21.1) (2025-01-24)

### Bug Fixes

- **no-redundant-files:** detect variations of README.md as redundant ([#765](https://github.com/michaelfaith/eslint-plugin-package-json/issues/765)) ([7453095](https://github.com/michaelfaith/eslint-plugin-package-json/commit/745309536c3d2c175591582147028754f9287b1d)), closes [#763](https://github.com/michaelfaith/eslint-plugin-package-json/issues/763) [#763](https://github.com/michaelfaith/eslint-plugin-package-json/issues/763)
- **no-redundant-files:** detect variations of README.md as redundant ([#765](https://github.com/michaelfaith/eslint-plugin-package-json/issues/765)) ([7453095](https://github.com/michaelfaith/eslint-plugin-package-json/commit/745309536c3d2c175591582147028754f9287b1d)), closes [#763](https://github.com/michaelfaith/eslint-plugin-package-json/issues/763) [#763](https://github.com/michaelfaith/eslint-plugin-package-json/issues/763)

## [0.21.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.20.1...v0.21.0) (2025-01-23)
## [0.21.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.20.1...v0.21.0) (2025-01-23)

### Features

- add no-empty-fields rule ([#741](https://github.com/michaelfaith/eslint-plugin-package-json/issues/741)) ([e57765b](https://github.com/michaelfaith/eslint-plugin-package-json/commit/e57765b3de7c4703f1c697d54758e5789494281a)), closes [#683](https://github.com/michaelfaith/eslint-plugin-package-json/issues/683)
- add no-empty-fields rule ([#741](https://github.com/michaelfaith/eslint-plugin-package-json/issues/741)) ([e57765b](https://github.com/michaelfaith/eslint-plugin-package-json/commit/e57765b3de7c4703f1c697d54758e5789494281a)), closes [#683](https://github.com/michaelfaith/eslint-plugin-package-json/issues/683)

## [0.20.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.20.0...v0.20.1) (2025-01-19)
## [0.20.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.20.0...v0.20.1) (2025-01-19)

### Bug Fixes

- bump package-json-validator dep to 0.8 ([#735](https://github.com/michaelfaith/eslint-plugin-package-json/issues/735)) ([29a9722](https://github.com/michaelfaith/eslint-plugin-package-json/commit/29a9722c15d39984ea99c2be346e20c2f4f9c76e)), closes [#734](https://github.com/michaelfaith/eslint-plugin-package-json/issues/734)
- bump package-json-validator dep to 0.8 ([#735](https://github.com/michaelfaith/eslint-plugin-package-json/issues/735)) ([29a9722](https://github.com/michaelfaith/eslint-plugin-package-json/commit/29a9722c15d39984ea99c2be346e20c2f4f9c76e)), closes [#734](https://github.com/michaelfaith/eslint-plugin-package-json/issues/734)

## [0.20.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.19.0...v0.20.0) (2025-01-17)
## [0.20.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.19.0...v0.20.0) (2025-01-17)

### Features

- **no-redundant-files:** add new rule ([#721](https://github.com/michaelfaith/eslint-plugin-package-json/issues/721)) ([1167f5e](https://github.com/michaelfaith/eslint-plugin-package-json/commit/1167f5ea698bf09e2dfe77147464cc3a3d5ee6e7)), closes [#686](https://github.com/michaelfaith/eslint-plugin-package-json/issues/686) [#686](https://github.com/michaelfaith/eslint-plugin-package-json/issues/686)
- **no-redundant-files:** add new rule ([#721](https://github.com/michaelfaith/eslint-plugin-package-json/issues/721)) ([1167f5e](https://github.com/michaelfaith/eslint-plugin-package-json/commit/1167f5ea698bf09e2dfe77147464cc3a3d5ee6e7)), closes [#686](https://github.com/michaelfaith/eslint-plugin-package-json/issues/686) [#686](https://github.com/michaelfaith/eslint-plugin-package-json/issues/686)

## [0.19.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.18.0...v0.19.0) (2024-12-31)
## [0.19.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.18.0...v0.19.0) (2024-12-31)

### Features

- **valid-package-definition:** rename rule from valid-package-def ([#711](https://github.com/michaelfaith/eslint-plugin-package-json/issues/711)) ([4f3907b](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4f3907b83ce1ddadcfbb572e70559e22b9c4a917)), closes [#132](https://github.com/michaelfaith/eslint-plugin-package-json/issues/132) [#132](https://github.com/michaelfaith/eslint-plugin-package-json/issues/132)
- **valid-package-definition:** rename rule from valid-package-def ([#711](https://github.com/michaelfaith/eslint-plugin-package-json/issues/711)) ([4f3907b](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4f3907b83ce1ddadcfbb572e70559e22b9c4a917)), closes [#132](https://github.com/michaelfaith/eslint-plugin-package-json/issues/132) [#132](https://github.com/michaelfaith/eslint-plugin-package-json/issues/132)

## [0.18.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.17.0...v0.18.0) (2024-12-05)
## [0.18.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.17.0...v0.18.0) (2024-12-05)

### Features

- update sort-package-json to 12 ([#680](https://github.com/michaelfaith/eslint-plugin-package-json/issues/680)) ([566e85b](https://github.com/michaelfaith/eslint-plugin-package-json/commit/566e85b27ecff4997cd08e1fa00611b1b0e61db0)), closes [#679](https://github.com/michaelfaith/eslint-plugin-package-json/issues/679)
- update sort-package-json to 12 ([#680](https://github.com/michaelfaith/eslint-plugin-package-json/issues/680)) ([566e85b](https://github.com/michaelfaith/eslint-plugin-package-json/commit/566e85b27ecff4997cd08e1fa00611b1b0e61db0)), closes [#679](https://github.com/michaelfaith/eslint-plugin-package-json/issues/679)

## [0.17.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.16.0...v0.17.0) (2024-11-30)
## [0.17.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.16.0...v0.17.0) (2024-11-30)

### Features

- sort alphabetically with co-located hooks for `scripts` ([#632](https://github.com/michaelfaith/eslint-plugin-package-json/issues/632)) ([4ccae4f](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4ccae4f58e1695b792dd3d0daf46cedc134d9541)), closes [#499](https://github.com/michaelfaith/eslint-plugin-package-json/issues/499) [#499](https://github.com/michaelfaith/eslint-plugin-package-json/issues/499)
- sort alphabetically with co-located hooks for `scripts` ([#632](https://github.com/michaelfaith/eslint-plugin-package-json/issues/632)) ([4ccae4f](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4ccae4f58e1695b792dd3d0daf46cedc134d9541)), closes [#499](https://github.com/michaelfaith/eslint-plugin-package-json/issues/499) [#499](https://github.com/michaelfaith/eslint-plugin-package-json/issues/499)

## [0.16.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.15.6...v0.16.0) (2024-11-30)
## [0.16.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.15.6...v0.16.0) (2024-11-30)

### Features

- **sort-collections:** should sort `overrides` ([#668](https://github.com/michaelfaith/eslint-plugin-package-json/issues/668)) ([18129cd](https://github.com/michaelfaith/eslint-plugin-package-json/commit/18129cd5c4a0bf45709ea7fcb9fb316c2a639a71)), closes [#619](https://github.com/michaelfaith/eslint-plugin-package-json/issues/619)
- **sort-collections:** should sort `overrides` ([#668](https://github.com/michaelfaith/eslint-plugin-package-json/issues/668)) ([18129cd](https://github.com/michaelfaith/eslint-plugin-package-json/commit/18129cd5c4a0bf45709ea7fcb9fb316c2a639a71)), closes [#619](https://github.com/michaelfaith/eslint-plugin-package-json/issues/619)

## [0.15.6](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.15.5...v0.15.6) (2024-11-09)
## [0.15.6](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.15.5...v0.15.6) (2024-11-09)

### Bug Fixes

- add sorting exports field ([#615](https://github.com/michaelfaith/eslint-plugin-package-json/issues/615)) ([116c74b](https://github.com/michaelfaith/eslint-plugin-package-json/commit/116c74be65089d7cfb39f3dae2fcae18fe19a263)), closes [#000](https://github.com/michaelfaith/eslint-plugin-package-json/issues/000)
- add sorting exports field ([#615](https://github.com/michaelfaith/eslint-plugin-package-json/issues/615)) ([116c74b](https://github.com/michaelfaith/eslint-plugin-package-json/commit/116c74be65089d7cfb39f3dae2fcae18fe19a263)), closes [#000](https://github.com/michaelfaith/eslint-plugin-package-json/issues/000)

## [0.15.5](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.15.4...v0.15.5) (2024-11-06)
## [0.15.5](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.15.4...v0.15.5) (2024-11-06)

### Bug Fixes

- add plugin export ([#609](https://github.com/michaelfaith/eslint-plugin-package-json/issues/609)) ([a2c83b4](https://github.com/michaelfaith/eslint-plugin-package-json/commit/a2c83b42c231129efb97ec29a29f6ae361adcc26)), closes [#000](https://github.com/michaelfaith/eslint-plugin-package-json/issues/000)
- add plugin export ([#609](https://github.com/michaelfaith/eslint-plugin-package-json/issues/609)) ([a2c83b4](https://github.com/michaelfaith/eslint-plugin-package-json/commit/a2c83b42c231129efb97ec29a29f6ae361adcc26)), closes [#000](https://github.com/michaelfaith/eslint-plugin-package-json/issues/000)

## [0.15.4](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.15.3...v0.15.4) (2024-10-18)
## [0.15.4](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.15.3...v0.15.4) (2024-10-18)

### Bug Fixes

- update dependency package-json-validator to v0.7.0 ([#569](https://github.com/michaelfaith/eslint-plugin-package-json/issues/569)) ([9d44862](https://github.com/michaelfaith/eslint-plugin-package-json/commit/9d44862f29cef1e6e8d71facf55ac5cf907d979e)), closes [#000](https://github.com/michaelfaith/eslint-plugin-package-json/issues/000)
- update dependency package-json-validator to v0.7.0 ([#569](https://github.com/michaelfaith/eslint-plugin-package-json/issues/569)) ([9d44862](https://github.com/michaelfaith/eslint-plugin-package-json/commit/9d44862f29cef1e6e8d71facf55ac5cf907d979e)), closes [#000](https://github.com/michaelfaith/eslint-plugin-package-json/issues/000)

## [0.15.3](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.15.2...v0.15.3) (2024-09-12)
## [0.15.3](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.15.2...v0.15.3) (2024-09-12)

### Bug Fixes

- **valid-repository-directory:** use repository root for more accurate linting ([#498](https://github.com/michaelfaith/eslint-plugin-package-json/issues/498)) ([d149400](https://github.com/michaelfaith/eslint-plugin-package-json/commit/d1494001a7cbf3fa95041179004fa8ad03ef0d34)), closes [#252](https://github.com/michaelfaith/eslint-plugin-package-json/issues/252)
- **valid-repository-directory:** use repository root for more accurate linting ([#498](https://github.com/michaelfaith/eslint-plugin-package-json/issues/498)) ([d149400](https://github.com/michaelfaith/eslint-plugin-package-json/commit/d1494001a7cbf3fa95041179004fa8ad03ef0d34)), closes [#252](https://github.com/michaelfaith/eslint-plugin-package-json/issues/252)

## [0.15.2](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.15.1...v0.15.2) (2024-07-10)
## [0.15.2](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.15.1...v0.15.2) (2024-07-10)

### Bug Fixes

- skip check for name to match npm package when private is true ([#455](https://github.com/michaelfaith/eslint-plugin-package-json/issues/455)) ([cc10e05](https://github.com/michaelfaith/eslint-plugin-package-json/commit/cc10e052911688ca7cacb9761c2db7c24c826d3e)), closes [#000](https://github.com/michaelfaith/eslint-plugin-package-json/issues/000)
- skip check for name to match npm package when private is true ([#455](https://github.com/michaelfaith/eslint-plugin-package-json/issues/455)) ([cc10e05](https://github.com/michaelfaith/eslint-plugin-package-json/commit/cc10e052911688ca7cacb9761c2db7c24c826d3e)), closes [#000](https://github.com/michaelfaith/eslint-plugin-package-json/issues/000)

## [0.15.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.15.0...v0.15.1) (2024-07-10)
## [0.15.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.15.0...v0.15.1) (2024-07-10)

### Bug Fixes

- update package-json-validator ([#456](https://github.com/michaelfaith/eslint-plugin-package-json/issues/456)) ([1a8bda4](https://github.com/michaelfaith/eslint-plugin-package-json/commit/1a8bda47891c14c7434ad6242f33f9ad7c2e940f)), closes [#250](https://github.com/michaelfaith/eslint-plugin-package-json/issues/250)
- update package-json-validator ([#456](https://github.com/michaelfaith/eslint-plugin-package-json/issues/456)) ([1a8bda4](https://github.com/michaelfaith/eslint-plugin-package-json/commit/1a8bda47891c14c7434ad6242f33f9ad7c2e940f)), closes [#250](https://github.com/michaelfaith/eslint-plugin-package-json/issues/250)

## [0.15.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.14.0...v0.15.0) (2024-06-17)
## [0.15.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.14.0...v0.15.0) (2024-06-17)

### Features

- **order-properties:** more precise error reporting ([#328](https://github.com/michaelfaith/eslint-plugin-package-json/issues/328)) ([4a3fbc8](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4a3fbc8046d4286ca950b1de9000f12bdadfa961)), closes [#320](https://github.com/michaelfaith/eslint-plugin-package-json/issues/320)
- **order-properties:** more precise error reporting ([#328](https://github.com/michaelfaith/eslint-plugin-package-json/issues/328)) ([4a3fbc8](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4a3fbc8046d4286ca950b1de9000f12bdadfa961)), closes [#320](https://github.com/michaelfaith/eslint-plugin-package-json/issues/320)

## [0.14.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.13.1...v0.14.0) (2024-05-31)
## [0.14.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.13.1...v0.14.0) (2024-05-31)

### Features

- add name field to recommended config ([#329](https://github.com/michaelfaith/eslint-plugin-package-json/issues/329)) ([b7a1a37](https://github.com/michaelfaith/eslint-plugin-package-json/commit/b7a1a37afb35c8040fa77abaaeb669d3935e5e14)), closes [#308](https://github.com/michaelfaith/eslint-plugin-package-json/issues/308)
- add name field to recommended config ([#329](https://github.com/michaelfaith/eslint-plugin-package-json/issues/329)) ([b7a1a37](https://github.com/michaelfaith/eslint-plugin-package-json/commit/b7a1a37afb35c8040fa77abaaeb669d3935e5e14)), closes [#308](https://github.com/michaelfaith/eslint-plugin-package-json/issues/308)

## [0.13.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.13.0...v0.13.1) (2024-04-29)
## [0.13.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.13.0...v0.13.1) (2024-04-29)

### Bug Fixes

- rule order-properties not work ([#315](https://github.com/michaelfaith/eslint-plugin-package-json/issues/315)) ([3a477f5](https://github.com/michaelfaith/eslint-plugin-package-json/commit/3a477f5f9e6223bff49d0a3b3cb33633bed7b76e)), closes [#000](https://github.com/michaelfaith/eslint-plugin-package-json/issues/000)
- rule order-properties not work ([#315](https://github.com/michaelfaith/eslint-plugin-package-json/issues/315)) ([3a477f5](https://github.com/michaelfaith/eslint-plugin-package-json/commit/3a477f5f9e6223bff49d0a3b3cb33633bed7b76e)), closes [#000](https://github.com/michaelfaith/eslint-plugin-package-json/issues/000)

## [0.13.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.12.1...v0.13.0) (2024-04-29)
## [0.13.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.12.1...v0.13.0) (2024-04-29)

### Bug Fixes

- correct suggestion status ([#299](https://github.com/michaelfaith/eslint-plugin-package-json/issues/299)) ([146e25d](https://github.com/michaelfaith/eslint-plugin-package-json/commit/146e25dc1f837eb3cd64d4862bf5e035dbb250e2)), closes [#255](https://github.com/michaelfaith/eslint-plugin-package-json/issues/255)
- correct suggestion status ([#299](https://github.com/michaelfaith/eslint-plugin-package-json/issues/299)) ([146e25d](https://github.com/michaelfaith/eslint-plugin-package-json/commit/146e25dc1f837eb3cd64d4862bf5e035dbb250e2)), closes [#255](https://github.com/michaelfaith/eslint-plugin-package-json/issues/255)

### Features

- sort-order rule shouldn't change sub-keys, better auto-fix ([#312](https://github.com/michaelfaith/eslint-plugin-package-json/issues/312)) ([a894550](https://github.com/michaelfaith/eslint-plugin-package-json/commit/a89455019be1a41309c7b3cab0a9acefbd7abeb2)), closes [#80](https://github.com/michaelfaith/eslint-plugin-package-json/issues/80)
- sort-order rule shouldn't change sub-keys, better auto-fix ([#312](https://github.com/michaelfaith/eslint-plugin-package-json/issues/312)) ([a894550](https://github.com/michaelfaith/eslint-plugin-package-json/commit/a89455019be1a41309c7b3cab0a9acefbd7abeb2)), closes [#80](https://github.com/michaelfaith/eslint-plugin-package-json/issues/80)

## [0.12.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.12.0...v0.12.1) (2024-03-28)
## [0.12.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.12.0...v0.12.1) (2024-03-28)

### Bug Fixes

- **valid-package-def:** ignore pnpm workspace protocol ([#258](https://github.com/michaelfaith/eslint-plugin-package-json/issues/258)) ([4b061e6](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4b061e6540fb914d004337bb89a90fedfb94b0f7)), closes [#251](https://github.com/michaelfaith/eslint-plugin-package-json/issues/251)
- **valid-package-def:** ignore pnpm workspace protocol ([#258](https://github.com/michaelfaith/eslint-plugin-package-json/issues/258)) ([4b061e6](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4b061e6540fb914d004337bb89a90fedfb94b0f7)), closes [#251](https://github.com/michaelfaith/eslint-plugin-package-json/issues/251)

## [0.12.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.11.0...v0.12.0) (2024-03-25)
## [0.12.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.11.0...v0.12.0) (2024-03-25)

### Features

- switch prefer-repository-shorthand to repository-shorthand ([#248](https://github.com/michaelfaith/eslint-plugin-package-json/issues/248)) ([580edb3](https://github.com/michaelfaith/eslint-plugin-package-json/commit/580edb3957cd4d8229bf73c10b1f7f65f79dc53f)), closes [#223](https://github.com/michaelfaith/eslint-plugin-package-json/issues/223)
- switch prefer-repository-shorthand to repository-shorthand ([#248](https://github.com/michaelfaith/eslint-plugin-package-json/issues/248)) ([580edb3](https://github.com/michaelfaith/eslint-plugin-package-json/commit/580edb3957cd4d8229bf73c10b1f7f65f79dc53f)), closes [#223](https://github.com/michaelfaith/eslint-plugin-package-json/issues/223)

## [0.11.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.10.4...v0.11.0) (2024-03-24)
## [0.11.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.10.4...v0.11.0) (2024-03-24)

### Features

- support flat config ([#161](https://github.com/michaelfaith/eslint-plugin-package-json/issues/161)) ([bf31a6c](https://github.com/michaelfaith/eslint-plugin-package-json/commit/bf31a6cb491afe0d43b29bc830d3b4c24bd1cf6d)), closes [#91](https://github.com/michaelfaith/eslint-plugin-package-json/issues/91)
- support flat config ([#161](https://github.com/michaelfaith/eslint-plugin-package-json/issues/161)) ([bf31a6c](https://github.com/michaelfaith/eslint-plugin-package-json/commit/bf31a6cb491afe0d43b29bc830d3b4c24bd1cf6d)), closes [#91](https://github.com/michaelfaith/eslint-plugin-package-json/issues/91)

## [0.10.4](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.10.3...v0.10.4) (2024-02-20)
## [0.10.4](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.10.3...v0.10.4) (2024-02-20)

### Bug Fixes

- can not import in ESM package ([#159](https://github.com/michaelfaith/eslint-plugin-package-json/issues/159)) ([2ce1881](https://github.com/michaelfaith/eslint-plugin-package-json/commit/2ce188156d0b91fdcb9606e069a45148c673e6c0)), closes [#152](https://github.com/michaelfaith/eslint-plugin-package-json/issues/152) [#157](https://github.com/michaelfaith/eslint-plugin-package-json/issues/157)
- can not import in ESM package ([#159](https://github.com/michaelfaith/eslint-plugin-package-json/issues/159)) ([2ce1881](https://github.com/michaelfaith/eslint-plugin-package-json/commit/2ce188156d0b91fdcb9606e069a45148c673e6c0)), closes [#152](https://github.com/michaelfaith/eslint-plugin-package-json/issues/152) [#157](https://github.com/michaelfaith/eslint-plugin-package-json/issues/157)

## [0.10.3](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.10.2...v0.10.3) (2024-02-20)
## [0.10.3](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.10.2...v0.10.3) (2024-02-20)

### Bug Fixes

- ignore npm alias version range error ([#156](https://github.com/michaelfaith/eslint-plugin-package-json/issues/156)) ([4436638](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4436638aba4eb727d4d09cc3e33bca04faf18620)), closes [#153](https://github.com/michaelfaith/eslint-plugin-package-json/issues/153)
- ignore npm alias version range error ([#156](https://github.com/michaelfaith/eslint-plugin-package-json/issues/156)) ([4436638](https://github.com/michaelfaith/eslint-plugin-package-json/commit/4436638aba4eb727d4d09cc3e33bca04faf18620)), closes [#153](https://github.com/michaelfaith/eslint-plugin-package-json/issues/153)

## [0.10.2](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.10.1...v0.10.2) (2024-02-01)
## [0.10.2](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.10.1...v0.10.2) (2024-02-01)

### Bug Fixes

- support Windows paths, again ([#144](https://github.com/michaelfaith/eslint-plugin-package-json/issues/144)) ([27243fa](https://github.com/michaelfaith/eslint-plugin-package-json/commit/27243fa5e6d0d59362e19f49135f69300949d282)), closes [#142](https://github.com/michaelfaith/eslint-plugin-package-json/issues/142) [#30](https://github.com/michaelfaith/eslint-plugin-package-json/issues/30)
- support Windows paths, again ([#144](https://github.com/michaelfaith/eslint-plugin-package-json/issues/144)) ([27243fa](https://github.com/michaelfaith/eslint-plugin-package-json/commit/27243fa5e6d0d59362e19f49135f69300949d282)), closes [#142](https://github.com/michaelfaith/eslint-plugin-package-json/issues/142) [#30](https://github.com/michaelfaith/eslint-plugin-package-json/issues/30)

## [0.10.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.10.0...v0.10.1) (2024-01-25)
## [0.10.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.10.0...v0.10.1) (2024-01-25)

### Bug Fixes

- incorrect example in 'sort-collections' ([#137](https://github.com/michaelfaith/eslint-plugin-package-json/issues/137)) ([88a94a0](https://github.com/michaelfaith/eslint-plugin-package-json/commit/88a94a06e0db5624f83fab22144d7096a0cd1a3a)), closes [#136](https://github.com/michaelfaith/eslint-plugin-package-json/issues/136)
- incorrect example in 'sort-collections' ([#137](https://github.com/michaelfaith/eslint-plugin-package-json/issues/137)) ([88a94a0](https://github.com/michaelfaith/eslint-plugin-package-json/commit/88a94a06e0db5624f83fab22144d7096a0cd1a3a)), closes [#136](https://github.com/michaelfaith/eslint-plugin-package-json/issues/136)

## [0.10.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.9.0...v0.10.0) (2024-01-20)
## [0.10.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.9.0...v0.10.0) (2024-01-20)

### Features

- added valid-version rule ([#135](https://github.com/michaelfaith/eslint-plugin-package-json/issues/135)) ([6e8b6fb](https://github.com/michaelfaith/eslint-plugin-package-json/commit/6e8b6fbe777d03731f5552c980eaad4e5f8d4dad)), closes [#130](https://github.com/michaelfaith/eslint-plugin-package-json/issues/130)
- added valid-version rule ([#135](https://github.com/michaelfaith/eslint-plugin-package-json/issues/135)) ([6e8b6fb](https://github.com/michaelfaith/eslint-plugin-package-json/commit/6e8b6fbe777d03731f5552c980eaad4e5f8d4dad)), closes [#130](https://github.com/michaelfaith/eslint-plugin-package-json/issues/130)

## [0.9.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.8.1...v0.9.0) (2024-01-20)
## [0.9.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.8.1...v0.9.0) (2024-01-20)

### Features

- added valid-name rule ([#134](https://github.com/michaelfaith/eslint-plugin-package-json/issues/134)) ([ecf9266](https://github.com/michaelfaith/eslint-plugin-package-json/commit/ecf926602f760c3edf1a832615624210a90ed3ed)), closes [#131](https://github.com/michaelfaith/eslint-plugin-package-json/issues/131)
- added valid-name rule ([#134](https://github.com/michaelfaith/eslint-plugin-package-json/issues/134)) ([ecf9266](https://github.com/michaelfaith/eslint-plugin-package-json/commit/ecf926602f760c3edf1a832615624210a90ed3ed)), closes [#131](https://github.com/michaelfaith/eslint-plugin-package-json/issues/131)

## [0.8.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.8.0...v0.8.1) (2024-01-20)
## [0.8.1](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.8.0...v0.8.1) (2024-01-20)

### Bug Fixes

- correct order-properties key checks ([#129](https://github.com/michaelfaith/eslint-plugin-package-json/issues/129)) ([a635c27](https://github.com/michaelfaith/eslint-plugin-package-json/commit/a635c279552beea4b0e5a611321d9f92083416e4)), closes [#127](https://github.com/michaelfaith/eslint-plugin-package-json/issues/127) [#128](https://github.com/michaelfaith/eslint-plugin-package-json/issues/128) [#127](https://github.com/michaelfaith/eslint-plugin-package-json/issues/127) [#128](https://github.com/michaelfaith/eslint-plugin-package-json/issues/128)
- correct order-properties key checks ([#129](https://github.com/michaelfaith/eslint-plugin-package-json/issues/129)) ([a635c27](https://github.com/michaelfaith/eslint-plugin-package-json/commit/a635c279552beea4b0e5a611321d9f92083416e4)), closes [#127](https://github.com/michaelfaith/eslint-plugin-package-json/issues/127) [#128](https://github.com/michaelfaith/eslint-plugin-package-json/issues/128) [#127](https://github.com/michaelfaith/eslint-plugin-package-json/issues/127) [#128](https://github.com/michaelfaith/eslint-plugin-package-json/issues/128)

## [0.8.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.7.0...v0.8.0) (2024-01-20)
## [0.8.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.7.0...v0.8.0) (2024-01-20)

### Features

- added unique-dependencies rule ([#126](https://github.com/michaelfaith/eslint-plugin-package-json/issues/126)) ([a9417d1](https://github.com/michaelfaith/eslint-plugin-package-json/commit/a9417d1685808dd8e4c27eff9e3b9c7399be6e1b)), closes [#50](https://github.com/michaelfaith/eslint-plugin-package-json/issues/50)
- added unique-dependencies rule ([#126](https://github.com/michaelfaith/eslint-plugin-package-json/issues/126)) ([a9417d1](https://github.com/michaelfaith/eslint-plugin-package-json/commit/a9417d1685808dd8e4c27eff9e3b9c7399be6e1b)), closes [#50](https://github.com/michaelfaith/eslint-plugin-package-json/issues/50)

## [0.7.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.6.0...v0.7.0) (2024-01-20)
## [0.7.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.6.0...v0.7.0) (2024-01-20)

### Features

- added valid-repository-directory rule ([#123](https://github.com/michaelfaith/eslint-plugin-package-json/issues/123)) ([84035c3](https://github.com/michaelfaith/eslint-plugin-package-json/commit/84035c3f2bac376567eef767ba21f354a0d93f54)), closes [#53](https://github.com/michaelfaith/eslint-plugin-package-json/issues/53)
- added valid-repository-directory rule ([#123](https://github.com/michaelfaith/eslint-plugin-package-json/issues/123)) ([84035c3](https://github.com/michaelfaith/eslint-plugin-package-json/commit/84035c3f2bac376567eef767ba21f354a0d93f54)), closes [#53](https://github.com/michaelfaith/eslint-plugin-package-json/issues/53)

## [0.6.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.5.0...v0.6.0) (2024-01-20)
## [0.6.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.5.0...v0.6.0) (2024-01-20)

### Features

- change order-properties order default to sort-package-json ([#122](https://github.com/michaelfaith/eslint-plugin-package-json/issues/122)) ([246261d](https://github.com/michaelfaith/eslint-plugin-package-json/commit/246261dff5838c42add53fd45c03a5eadc495d83)), closes [#58](https://github.com/michaelfaith/eslint-plugin-package-json/issues/58)
- change order-properties order default to sort-package-json ([#122](https://github.com/michaelfaith/eslint-plugin-package-json/issues/122)) ([246261d](https://github.com/michaelfaith/eslint-plugin-package-json/commit/246261dff5838c42add53fd45c03a5eadc495d83)), closes [#58](https://github.com/michaelfaith/eslint-plugin-package-json/issues/58)

## [0.5.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.4.0...v0.5.0) (2024-01-20)
## [0.5.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.4.0...v0.5.0) (2024-01-20)

### Features

- add prefer-repository-shorthand rule ([#70](https://github.com/michaelfaith/eslint-plugin-package-json/issues/70)) ([0c7fb19](https://github.com/michaelfaith/eslint-plugin-package-json/commit/0c7fb199cdf0ba001bd996f6da2c4ba8cbbc7d0f)), closes [#71](https://github.com/michaelfaith/eslint-plugin-package-json/issues/71)
- add prefer-repository-shorthand rule ([#70](https://github.com/michaelfaith/eslint-plugin-package-json/issues/70)) ([0c7fb19](https://github.com/michaelfaith/eslint-plugin-package-json/commit/0c7fb199cdf0ba001bd996f6da2c4ba8cbbc7d0f)), closes [#71](https://github.com/michaelfaith/eslint-plugin-package-json/issues/71)

## [0.4.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.1.3...v0.4.0) (2024-01-20)
## [0.4.0](https://github.com/michaelfaith/eslint-plugin-package-json/compare/v0.1.3...v0.4.0) (2024-01-20)

### Bug Fixes

- detect package.json in Windows ([eb90172](https://github.com/michaelfaith/eslint-plugin-package-json/commit/eb901727c12fdd4f7a5d734c9e98f3123059bee8))
- Missing extension in valid-package-def link ([0cd9b6b](https://github.com/michaelfaith/eslint-plugin-package-json/commit/0cd9b6bd462b9b801cf69b1a09d8c23d4afcedf0))
- recommended config ([#103](https://github.com/michaelfaith/eslint-plugin-package-json/issues/103)) ([77dc134](https://github.com/michaelfaith/eslint-plugin-package-json/commit/77dc1344ea7a34abcb6c0e87d61b65149b4fe2ca)), closes [#102](https://github.com/michaelfaith/eslint-plugin-package-json/issues/102)
- typo ([#63](https://github.com/michaelfaith/eslint-plugin-package-json/issues/63)) ([3e6f6bc](https://github.com/michaelfaith/eslint-plugin-package-json/commit/3e6f6bc40ed8a856199082429e66c77c099210f5))
- detect package.json in Windows ([eb90172](https://github.com/michaelfaith/eslint-plugin-package-json/commit/eb901727c12fdd4f7a5d734c9e98f3123059bee8))
- Missing extension in valid-package-def link ([0cd9b6b](https://github.com/michaelfaith/eslint-plugin-package-json/commit/0cd9b6bd462b9b801cf69b1a09d8c23d4afcedf0))
- recommended config ([#103](https://github.com/michaelfaith/eslint-plugin-package-json/issues/103)) ([77dc134](https://github.com/michaelfaith/eslint-plugin-package-json/commit/77dc1344ea7a34abcb6c0e87d61b65149b4fe2ca)), closes [#102](https://github.com/michaelfaith/eslint-plugin-package-json/issues/102)
- typo ([#63](https://github.com/michaelfaith/eslint-plugin-package-json/issues/63)) ([3e6f6bc](https://github.com/michaelfaith/eslint-plugin-package-json/commit/3e6f6bc40ed8a856199082429e66c77c099210f5))

### Features

- converted to TypeScript ([#59](https://github.com/michaelfaith/eslint-plugin-package-json/issues/59)) ([c328633](https://github.com/michaelfaith/eslint-plugin-package-json/commit/c3286338cb98a3d5570ff95424057317a2881fa1)), closes [#60](https://github.com/michaelfaith/eslint-plugin-package-json/issues/60) [#35](https://github.com/michaelfaith/eslint-plugin-package-json/issues/35)
- converted to TypeScript ([#59](https://github.com/michaelfaith/eslint-plugin-package-json/issues/59)) ([c328633](https://github.com/michaelfaith/eslint-plugin-package-json/commit/c3286338cb98a3d5570ff95424057317a2881fa1)), closes [#60](https://github.com/michaelfaith/eslint-plugin-package-json/issues/60) [#35](https://github.com/michaelfaith/eslint-plugin-package-json/issues/35)
