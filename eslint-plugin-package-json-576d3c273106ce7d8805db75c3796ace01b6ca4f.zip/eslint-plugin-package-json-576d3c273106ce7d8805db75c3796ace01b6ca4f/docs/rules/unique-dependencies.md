# unique-dependencies

> [!NOTE]
> You can find the docs for this rule on our website: <https://eslint-plugin-package-json.dev/rules/unique-dependencies>
